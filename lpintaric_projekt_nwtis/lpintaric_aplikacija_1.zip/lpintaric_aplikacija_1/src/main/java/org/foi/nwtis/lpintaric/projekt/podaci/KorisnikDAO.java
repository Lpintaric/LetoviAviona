package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

public class KorisnikDAO {

    public Korisnik dohvatiKorisnika(String korisnik, String lozinka, Boolean prijava, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * "
                + "FROM korisnici WHERE korime = '" + korisnik + "'";

        if (prijava) {
            upit += " AND lozinka = '" + lozinka + "'";
        }

        try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();
                    ResultSet rs = s.executeQuery(upit);
                    ) {
                
                while (rs.next()) {
                    String korime = rs.getString("KORIME");
                    String loz = rs.getString("LOZINKA");
                    String prezime = rs.getString("PREZIME");
                    String ime = rs.getString("IME");

                    Korisnik k = new Korisnik(korime, "*******", prezime, ime);
                    return k;
                }
            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public List<Korisnik> dohvatiSveKorisnike(PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * FROM korisnici";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            List<Korisnik> korisnici = new ArrayList<>();

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                     Statement s = con.createStatement();
                     ResultSet rs = s.executeQuery(upit)) {

                while (rs.next()) {
                    String korisnik1 = rs.getString("KORIME");
                    String ime = rs.getString("IME");
                    String prezime = rs.getString("PREZIME");
                    Korisnik k = new Korisnik(korisnik1, "******", prezime, ime);

                    korisnici.add(k);
                }
                return korisnici;

            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
//
//    public boolean azurirajKorisnika(Korisnik k, String lozinka, PostavkeBazaPodataka pbp) {
//        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
//        String bpkorisnik = pbp.getUserUsername();
//        String bplozinka = pbp.getUserPassword();
//        String upit = "UPDATE korisnici SET ime = ?, prezime = ?, emailAdresa = ?, lozinka = ?, "
//                + "vrijemePromjene = CURRENT_TIMESTAMP WHERE korisnik = ?";
//
//        try {
//            Class.forName(pbp.getDriverDatabase(url));
//
//            try (
//                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
//                     PreparedStatement s = con.prepareStatement(upit)) {
//
//                s.setString(1, k.getIme());
//                s.setString(2, k.getPrezime());
//                s.setString(3, k.getEmailAdresa());
//                s.setString(4, lozinka);
//                s.setString(5, k.getKorisnik());
//
//                int brojAzuriranja = s.executeUpdate();
//
//                return brojAzuriranja == 1;
//
//            } catch (SQLException ex) {
//                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return false;
//    }
//
    public boolean dodajKorisnika(Korisnik k, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "INSERT INTO korisnici (korime, lozinka, prezime, ime) "
                + "VALUES ('" + k.getKorime() + "', '" + k.getLozinka() + "', '" + k.getPrezime() + "', '" + k.getIme() + "')";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();) {

                int brojAzuriranja = s.executeUpdate(upit);

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
