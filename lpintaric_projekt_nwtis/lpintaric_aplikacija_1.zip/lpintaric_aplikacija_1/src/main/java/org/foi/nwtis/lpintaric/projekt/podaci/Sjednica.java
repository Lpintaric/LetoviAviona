package org.foi.nwtis.lpintaric.projekt.podaci;

/**
 * Klasa koja predstavlja entitet sjednice.
 * Kod kreiranja objekta prima četiri paremetra: 
 * redni broj sjednice, korisničko ime, vrijeme
 * kreiranja, vrijeme isteka.
 * 
 * @author Luka Pintarić
 * @version 1.0
 */
public class Sjednica {
    
    /**
     * Redni broj sjednice
     */
    int id;
    /**
     * Korisničko ime
     */
    String korisnik;
    /**
     * Vrijeme kada je kreirana sjednica
     */
    long vrijemeKreiranja;
    /**
     * Vrijeme do kada vrijedi sjednica
     */
    long vrijemeDoKadaVrijedi;
    
    int brojPreostalihZahtjeva;

    public Sjednica(int id, String korisnik, long vrijemeKreiranja, long vrijemeDoKadaVrijedi, int brojPreostalihZahtjeva) {
        this.id = id;
        this.korisnik = korisnik;
        this.vrijemeKreiranja = vrijemeKreiranja;
        this.vrijemeDoKadaVrijedi = vrijemeDoKadaVrijedi;
        this.brojPreostalihZahtjeva = brojPreostalihZahtjeva;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    

    public long getVrijemeKreiranja() {
        return vrijemeKreiranja;
    }

    public void setVrijemeKreiranja(long vrijemeKreiranja) {
        this.vrijemeKreiranja = vrijemeKreiranja;
    }

    public long getVrijemeDoKadaVrijedi() {
        return vrijemeDoKadaVrijedi;
    }

    public void setVrijemeDoKadaVrijedi(long vrijemeDoKadaVrijedi) {
        this.vrijemeDoKadaVrijedi = vrijemeDoKadaVrijedi;
    }

    public int getBrojPreostalihZahtjeva() {
        return brojPreostalihZahtjeva;
    }

    public void setBrojPreostalihZahtjeva(int brojPreostalihZahtjeva) {
        this.brojPreostalihZahtjeva = brojPreostalihZahtjeva;
    }
    
    

    
    
    
}
