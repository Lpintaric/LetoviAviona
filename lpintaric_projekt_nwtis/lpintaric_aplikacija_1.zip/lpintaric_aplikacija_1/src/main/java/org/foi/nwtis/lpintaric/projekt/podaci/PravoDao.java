package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

public class PravoDao {
    public Pravo dohvatiPravo(String korime, String podrucje, PostavkeBazaPodataka pbp){
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        
        String upit = "SELECT * "
                + "FROM prava WHERE korime = '" + korime + "'" 
                + " AND podrucje_rada = '" + podrucje + "'";
        
        try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();
                    ResultSet rs = s.executeQuery(upit);
                    ) {
                
                while (rs.next()) {
                    String korime1 = rs.getString("KORIME");
                    String podrucje1 = rs.getString("PODRUCJE_RADA");
                    boolean status = rs.getBoolean("STATUS");
                    
                    Pravo p = new Pravo(korime1, podrucje1, status);
                    return p;
                }
            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public Pravo dohvatiVazecePravo(String korime, String podrucje, PostavkeBazaPodataka pbp){
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        
        String upit = "SELECT * "
                + "FROM prava WHERE korime = '" + korime + "'" 
                + " AND podrucje_rada = '" + podrucje + "'"
                + " AND status = true";
        
        try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();
                    ResultSet rs = s.executeQuery(upit);
                    ) {
                
                while (rs.next()) {
                    String korime1 = rs.getString("KORIME");
                    String podrucje1 = rs.getString("PODRUCJE_RADA");
                    boolean status = rs.getBoolean("STATUS");
                    
                    Pravo p = new Pravo(korime1, podrucje1, status);
                    return p;
                }
            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public List<Pravo> dohvatiSvaAktivnaPravaKorisnika(String korime, PostavkeBazaPodataka pbp){
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        
        String upit = "SELECT * "
                + "FROM prava WHERE korime = '" + korime + "' AND status = TRUE";
        
        List<Pravo> prava = new ArrayList<>();
        
        try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();
                    ResultSet rs = s.executeQuery(upit);
                    ) {
                
                while (rs.next()) {
                    String korime1 = rs.getString("KORIME");
                    String podrucje1 = rs.getString("PODRUCJE_RADA");
                    boolean status = rs.getBoolean("STATUS");
                    
                    Pravo p = new Pravo(korime1, podrucje1, status);
                    
                    prava.add(p);
                }
                return prava;
            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean azurirajPravo(String korime, String podrucje, boolean status, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "UPDATE prava SET status = '" + status + "' WHERE korime = '" + korime 
                + "' AND podrucje_rada = '" + podrucje + "'";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();) {

                int brojAzuriranja = s.executeUpdate(upit);

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean dodajPravo(Pravo p, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "INSERT INTO prava (korime, podrucje_rada, status) "
                + "VALUES ('" + p.getKorime() + "', '" + p.getPodrucje_rada() + "', '" + p.isStatus() + "')";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement();) {

                int brojAzuriranja = s.executeUpdate(upit);

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KorisnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
