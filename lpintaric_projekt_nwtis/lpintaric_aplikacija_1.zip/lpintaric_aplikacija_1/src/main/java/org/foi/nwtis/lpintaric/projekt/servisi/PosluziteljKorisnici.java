package org.foi.nwtis.lpintaric.projekt.servisi;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.projekt.klijenti.DnevnikKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.Dnevnik;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.KorisnikDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.Pravo;
import org.foi.nwtis.lpintaric.projekt.podaci.PravoDao;
import org.foi.nwtis.lpintaric.projekt.podaci.Sjednica;

public class PosluziteljKorisnici extends Thread {

    private PostavkeBazaPodataka pbp;
    private Integer port;
    private boolean krajRada;
    private ServerSocket ss;
    private int sjednicaTrajanje;
    private List<Sjednica> sjednice = new ArrayList<Sjednica>();
    private int maksBrojZahtjeva;
    private int brojacIdSjednice;
    private int brojAktivnihDretvi = 0;
    private Integer maksDretvi;

    public PosluziteljKorisnici(PostavkeBazaPodataka pbp) {
        this.pbp = pbp;
    }

    @Override
    public void interrupt() {
        System.out.println("[PosluziteljKorisnici]Zaustavljam glavnu dretvu!");
        this.krajRada = true;
        try {
            ss.close();
        } catch (IOException ex) {
            Logger.getLogger(PosluziteljKorisnici.class.getName()).log(Level.SEVERE, null, ex);
        }
        super.interrupt();
    }

    @Override
    public void run() {
        pokreniPosluzitelj(pbp);
    }

    private void pokreniPosluzitelj(PostavkeBazaPodataka pbp) {
        dohvatiPostavke();
        zapocniRad();
    }

    private void dohvatiPostavke() {
        System.out.println("[PosluziteljKorisnici]Dohvacam postavke");
        this.port = Integer.parseInt(pbp.dajPostavku("server.port"));
        this.sjednicaTrajanje = Integer.parseInt(pbp.dajPostavku("sjednica.trajanje"));
        this.maksBrojZahtjeva = Integer.parseInt(pbp.dajPostavku("sjednica.maksBrojZahtjeva"));
        this.maksDretvi = Integer.parseInt(pbp.dajPostavku("server.maksDretvi"));
    }

    private void zapocniRad() {
        try {
            ss = new ServerSocket(port);
            System.out.println("[PosluziteljKorisnici]Server je uspješno pokrenut! ");
            while (!krajRada) {
                System.out.println("[PosluziteljKorisnici]Cekam poruku");
                Socket uticnica = ss.accept();
                long vrijemeZahtjeva = dohvatiTrenutnoVrijemeSekunde();
                if(jeLiDosegnutMaksBrojDretvi(uticnica)){
                    continue;
                }
                ++brojAktivnihDretvi;
                
                pokreniDretvuZahtjeva(uticnica, vrijemeZahtjeva);
            }
        } catch (IOException ex) {
            System.out.println("ERROR 18 Utičnicu nije moguće kreirati! Port " + port + " je zauzet!");
        }
    }
    
    private long dohvatiTrenutnoVrijemeSekunde(){
        return (System.currentTimeMillis() + TimeUnit.HOURS.toMillis(2)) / 1000;
    }
    
    private boolean jeLiDosegnutMaksBrojDretvi(Socket uticnica) {
        if(brojAktivnihDretvi >= maksDretvi){
            try {
                OutputStream os = uticnica.getOutputStream();
                
                String odgovor = "ERROR 01 Nije moguće obraditi zahtjev! Dosegnut je maksimalan broj dretvi!";
                os.write(odgovor.getBytes());
                
                os.flush();
                uticnica.shutdownOutput();
                uticnica.close();
            } catch (IOException ex) {
                System.out.println("ERROR 18 Greška kod kreiranja izlaznog toka za utičnicu na portu '" + port + "'");
            }
            return true;
        }
        return false;
    }

    private void pokreniDretvuZahtjeva(Socket uticnica, long vrijemeZahtejva) {
        DretvaZahtjeva dz = new DretvaZahtjeva(uticnica, vrijemeZahtejva);
        System.out.println("[PosluziteljKorisnici]Pokrecem dretvu zahtjeva");
        dz.start();
    }

    public class DretvaZahtjeva extends Thread {

        private Socket uticnica;
        private long vrijemeZahtjeva;
        

        public DretvaZahtjeva(Socket uticnica, long vrijemeZahtjeva) {
            this.uticnica = uticnica;
            this.vrijemeZahtjeva = vrijemeZahtjeva;
        }

        @Override
        public void interrupt() {
            super.interrupt();
        }

        @Override
        public void run() {
            System.out.println("[PosluziteljKorisnici]Pocinjem obradu");

            obradiZahtjev();
        }

        public void obradiZahtjev() {
            String odgovor;
            try (InputStream is = uticnica.getInputStream();
                    OutputStream os = uticnica.getOutputStream();) {
                StringBuilder tekst = new StringBuilder();
                while (true) {
                    int i = is.read();
                    if (i == -1) {
                        break;
                    }
                    tekst.append((char) i);
                }
                uticnica.shutdownInput();

                String komanda = tekst.toString();
                System.out.println("ZAHTJEV: '" + komanda + "'");

                odgovor = izvrsiKomandu(komanda);
                System.out.println("ODGOVOR : " + odgovor);
                os.write(odgovor.getBytes());
                zapisiPodatkeUDnevnik(komanda, odgovor, vrijemeZahtjeva);
                os.flush();

                uticnica.shutdownOutput();
                uticnica.close();
            } catch (IOException ex) {
                System.out.println("ERROR 18 Greška kod kreiranja ulaznih i izlaznih tokova !");
            }
            brojAktivnihDretvi -= 1;
        }

        private String izvrsiKomandu(String komanda) {
            String odgovor = "";
            String[] dijeloviKomande = komanda.split(" ");

            if (Pattern.compile("ADD\\s([\\w]+)\\s([\\w]+)\\s\"([\\w]+)\"\\s\"([\\w]+)\"").matcher(komanda).matches()) {
                odgovor = dodajKorisnika(komanda);
            } else if (Pattern.compile("AUTHEN\\s([\\w]+)\\s([\\w]+)").matcher(komanda).matches()) {
                odgovor = autenticirajKorisnika(dijeloviKomande);
            } else if (Pattern.compile("LOGOUT\\s([\\w]+)\\s([\\d]+)").matcher(komanda).matches()) {
                odgovor = odjaviKorisnika(dijeloviKomande);
            } else if (Pattern.compile("GRANT\\s([\\w]+)\\s([\\d]+)\\s([\\w]+)\\s([\\w]+)").matcher(komanda).matches()) {
                odgovor = dodajDozvoluKorisniku(dijeloviKomande);
            } else if (Pattern.compile("REVOKE\\s([\\w]+)\\s([\\d]+)\\s([\\w]+)\\s([\\w]+)").matcher(komanda).matches()) {
                odgovor = oduzmiDozvoluKorisniku(dijeloviKomande); 
            } else if (Pattern.compile("RIGHTS\\s([\\w]+)\\s([\\d]+)\\s([\\w]+)").matcher(komanda).matches()) {
                odgovor = dohvatiListuDozvolaKorisnika(dijeloviKomande); 
            } else if (Pattern.compile("AUTHOR\\s([\\w]+)\\s([\\d]+)\\s([\\w]+)").matcher(komanda).matches()) {
                odgovor = autorizirajKorisnika(dijeloviKomande); 
            } else if (Pattern.compile("LIST\\s([\\w]+)\\s([\\d]+)\\s([\\w]+)").matcher(komanda).matches()) {
                odgovor = dohvatiPodatkeKorisnika(dijeloviKomande); 
            } else if (Pattern.compile("LISTALL\\s([\\w]+)\\s([\\d]+)").matcher(komanda).matches()) {
                odgovor = dohvatiPodatkeSvihKorisnika(dijeloviKomande); 
            } else {
                odgovor = "ERROR 10 Pogrešna sintaksa komande !";
            }

            return odgovor;
        }

        private String dodajKorisnika(String komanda) {
            String dijeloviRazmak[] = komanda.split(" ");
            String dijeloviNavodnik[] = komanda.split("\"");

            String korime = dijeloviRazmak[1];
            String lozinka = dijeloviRazmak[2];
            String prezime = dijeloviNavodnik[1];
            String ime = dijeloviNavodnik[3];

            Korisnik k = new Korisnik(korime, lozinka, prezime, ime);

            KorisnikDAO kdao = new KorisnikDAO();
            if (kdao.dohvatiKorisnika(korime, lozinka, false, pbp) != null) {
                return "ERROR 18 Korisnik već postoji !";
            }

            if (kdao.dodajKorisnika(k, pbp)) {
                return "OK";
            } else {
                return "ERROR 18 Greska kod dodavanja korisnika u bazu !";
            }
        }

        private String autenticirajKorisnika(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], dijeloviKomande[2], true, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            } else {
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                ).findAny().orElse(null);
                if (sjednica != null) {
                    int index = sjednice.indexOf(sjednica);
                    sjednica.setVrijemeKreiranja(trenutnoVrijeme);
                    sjednica.setVrijemeDoKadaVrijedi(trenutnoVrijeme + sjednicaTrajanje);
                    sjednice.set(index, sjednica);

                    return "OK " + sjednica.getId() + " " + sjednica.getVrijemeDoKadaVrijedi()
                            + " " + sjednica.getBrojPreostalihZahtjeva();
                } else {
                    Sjednica novaSjednica = new Sjednica(
                            ++brojacIdSjednice,
                            k.getKorime(),
                            trenutnoVrijeme,
                            trenutnoVrijeme + sjednicaTrajanje,
                            maksBrojZahtjeva);
                    sjednice.add(novaSjednica);
                    return "OK " + novaSjednica.getId() + " " + novaSjednica.getVrijemeDoKadaVrijedi()
                            + " " + novaSjednica.getBrojPreostalihZahtjeva();
                }
            }
        }

        private String odjaviKorisnika(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null) {
                    int index = sjednice.indexOf(sjednica);
                    sjednica.setVrijemeDoKadaVrijedi(trenutnoVrijeme);
                    sjednica.setBrojPreostalihZahtjeva(0);
                    sjednice.remove(index);

                    return "OK";
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private String dodajDozvoluKorisniku(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null) {
                    if(sjednica.getBrojPreostalihZahtjeva() == 0){
                        return "ERROR 16 Nema više preostalih zahtjeva";
                    }else{
                        int index = sjednice.indexOf(sjednica);
                        sjednica.setBrojPreostalihZahtjeva(sjednica.getBrojPreostalihZahtjeva() - 1);
                        sjednice.set(index, sjednica);
                        
                        PravoDao pdao = new PravoDao();
                        Pravo p = pdao.dohvatiPravo(dijeloviKomande[4], dijeloviKomande[3], pbp);
                        
                        if (p == null){
                            Pravo p1 = new Pravo(dijeloviKomande[4], dijeloviKomande[3], true);
                            pdao.dodajPravo(p1, pbp);
                            return "OK";
                        }else{
                            if(p.isStatus()){
                                return "ERROR 13 Podrucje je vec dodano !";
                            }else{
                                pdao.azurirajPravo(dijeloviKomande[4], dijeloviKomande[3], true, pbp);
                                return "OK";
                            }
                        }
                    }
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private String oduzmiDozvoluKorisniku(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null){
                    if(sjednica.getBrojPreostalihZahtjeva() == 0){
                        return "ERROR 16 Nema više preostalih zahtjeva";
                    }else{
                        int index = sjednice.indexOf(sjednica);
                        sjednica.setBrojPreostalihZahtjeva(sjednica.getBrojPreostalihZahtjeva() - 1);
                        sjednice.set(index, sjednica);
                        
                        PravoDao pdao = new PravoDao();
                        Pravo p = pdao.dohvatiPravo(dijeloviKomande[4], dijeloviKomande[3], pbp);
                        
                        if(p == null){
                            return "ERROR 18 Nema pridruzenog podrucja !";
                        }else{
                            if(p.isStatus()){
                                pdao.azurirajPravo(dijeloviKomande[4], dijeloviKomande[3], false, pbp);
                                return "OK";
                            }else{
                                return "ERROR 14 Podrucje je vec neaktivno !";
                            }
                        }
                    }
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private String dohvatiListuDozvolaKorisnika(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null){
                    if(sjednica.getBrojPreostalihZahtjeva() == 0){
                        return "ERROR 16 Nema više preostalih zahtjeva";
                    }else{
                        int index = sjednice.indexOf(sjednica);
                        sjednica.setBrojPreostalihZahtjeva(sjednica.getBrojPreostalihZahtjeva() - 1);
                        sjednice.set(index, sjednica);
                        
                        PravoDao pdao = new PravoDao();
                        List<Pravo> prava = pdao.dohvatiSvaAktivnaPravaKorisnika(dijeloviKomande[3], pbp);
                        
                        if(prava.size() <= 0){
                            return "ERROR 14 Nema aktivnih podrucja !";
                        }else{
                            String odgovor = "OK";
                            for (Pravo pravo : prava) {
                                if(pravo.isStatus()){
                                    odgovor += " " + pravo.getPodrucje_rada();
                                }
                            }
                            return odgovor;
                        }
                    }
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private String autorizirajKorisnika(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null) {
                    if(sjednica.getBrojPreostalihZahtjeva() == 0){
                        return "ERROR 16 Nema više preostalih zahtjeva";
                    }else{
                        int index = sjednice.indexOf(sjednica);
                        sjednica.setBrojPreostalihZahtjeva(sjednica.getBrojPreostalihZahtjeva() - 1);
                        sjednice.set(index, sjednica);
                        
                        PravoDao pdao = new PravoDao();
                        Pravo p = pdao.dohvatiVazecePravo(dijeloviKomande[1], dijeloviKomande[3], pbp);
                        
                        if (p == null){
                            return "ERROR 14 Korisnik nema pridruženo područje !";
                        }else{
                            return "OK";
                        }
                    }
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private String dohvatiPodatkeKorisnika(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null) {
                    if(sjednica.getBrojPreostalihZahtjeva() == 0){
                        return "ERROR 16 Nema više preostalih zahtjeva";
                    }else{
                        int index = sjednice.indexOf(sjednica);
                        sjednica.setBrojPreostalihZahtjeva(sjednica.getBrojPreostalihZahtjeva() - 1);
                        sjednice.set(index, sjednica);
                        
                        Korisnik k2 = kdao.dohvatiKorisnika(dijeloviKomande[3], "", false, pbp);
                        
                        if (k2 == null){
                            return "ERROR 17 Ne postoji trazeni korisnik !";
                        }else{
                            return "OK \"" + k2.getKorime() + "\t" + k2.getPrezime() + "\t" + k2.getIme()+ "\"" ;
                        }
                    }
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private String dohvatiPodatkeSvihKorisnika(String[] dijeloviKomande) {
            KorisnikDAO kdao = new KorisnikDAO();
            Korisnik k = kdao.dohvatiKorisnika(dijeloviKomande[1], "", false, pbp);
            if (k == null) {
                return "ERROR 11 Korisnik sa unesenim podacima ne postoji !";
            }else{
                long trenutnoVrijeme = System.currentTimeMillis();
                Sjednica sjednica = sjednice.stream().filter(x
                        -> x.getKorisnik().equals(dijeloviKomande[1])
                        && (x.getVrijemeDoKadaVrijedi() > trenutnoVrijeme)
                        && (x.getId() == Integer.parseInt(dijeloviKomande[2]))
                ).findAny().orElse(null);
                if (sjednica != null) {
                    if(sjednica.getBrojPreostalihZahtjeva() == 0){
                        return "ERROR 16 Nema više preostalih zahtjeva";
                    }else{
                        int index = sjednice.indexOf(sjednica);
                        sjednica.setBrojPreostalihZahtjeva(sjednica.getBrojPreostalihZahtjeva() - 1);
                        sjednice.set(index, sjednica);
                        
                        List<Korisnik> korisnici = kdao.dohvatiSveKorisnike(pbp);
                        
                        String odgovor = "OK";
                        for (Korisnik k2 : korisnici) {
                            odgovor += " \"" + k2.getKorime() + "\t" + k2.getPrezime() + "\t" + k2.getIme()+ "\"";
                        }
                        
                        return odgovor;
                    }
                }else{
                    return "ERROR 15 Korisnik nema važeću sjednicu !";
                }
            }
        }

        private void zapisiPodatkeUDnevnik(String komanda, String odgovor, long vrijemeZahtjeva) {
            String korisnik = komanda.split(" ")[1];
            
            String[] odgovorDijelovi = odgovor.split(" ");
            String status = "";
            if(odgovorDijelovi[0].equals("OK")){
                status = odgovorDijelovi[0];
            }else if(odgovorDijelovi[0].equals("ERROR")){
                status = odgovorDijelovi[0] + odgovorDijelovi[1];
            }
            
            Dnevnik d = new Dnevnik(korisnik, vrijemeZahtjeva, komanda, status);
            
            DnevnikKlijent_1 dk = new DnevnikKlijent_1();
            Response r = dk.dodajZapisUDnvenik(d, Response.class);
            
            if(r.getStatusInfo().toString().equals("OK")){
                System.out.println("[PosluziteljKorisnici]Dodan je zapis u dnevnik!");
            }
        }
    }
}
