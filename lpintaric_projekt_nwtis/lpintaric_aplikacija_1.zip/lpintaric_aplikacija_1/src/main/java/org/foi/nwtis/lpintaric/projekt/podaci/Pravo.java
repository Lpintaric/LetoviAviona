package org.foi.nwtis.lpintaric.projekt.podaci;

public class Pravo {
    private String korime;
    private String podrucje_rada;
    private boolean status;

    public Pravo(String korime, String podrucje_rada, boolean status) {
        this.korime = korime;
        this.podrucje_rada = podrucje_rada;
        this.status = status;
    }

    public String getKorime() {
        return korime;
    }

    public void setKorime(String korime) {
        this.korime = korime;
    }

    public String getPodrucje_rada() {
        return podrucje_rada;
    }

    public void setPodrucje_rada(String podrucje_rada) {
        this.podrucje_rada = podrucje_rada;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    
}
