package org.foi.nwtis.lpintaric.projekt.slusaci;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.websocket.ContainerProvider;
import jakarta.websocket.DeploymentException;
import jakarta.websocket.Session;
import jakarta.websocket.WebSocketContainer;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.vjezba_03.konfiguracije.NeispravnaKonfiguracija;

@WebListener
public class SlusacAplikacije implements ServletContextListener {
    
        
    @Override
    public void contextDestroyed(ServletContextEvent sce) {

        ServletContext servletContext = sce.getServletContext();
        servletContext.removeAttribute("Postavke");
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext servletContext = sce.getServletContext();
        
        String putanjaKonfDatoteke = servletContext.getRealPath("WEB-INF")+File.separator+servletContext.getInitParameter("konfiguracija");
        PostavkeBazaPodataka pbp = new PostavkeBazaPodataka(putanjaKonfDatoteke);
        
        try {
            pbp.ucitajKonfiguraciju();
            servletContext.setAttribute("Postavke", pbp);
        } catch (NeispravnaKonfiguracija ex) {
            Logger.getLogger(SlusacAplikacije.class.getName()).log(Level.SEVERE, null, ex);
        }   
        
        dohvatiPostavke(pbp, servletContext);
    }
    
    private void dohvatiPostavke(PostavkeBazaPodataka pbp, ServletContext servletContext) {
        int posluziteljKorisniciPort = Integer.parseInt(pbp.dajPostavku("posluziteljKorisnici.port"));
        servletContext.setAttribute("posluziteljKorisniciPort", posluziteljKorisniciPort);
        
        String posluziteljKorisniciAdresa = pbp.dajPostavku("posluziteljKorisnici.adresa");
        servletContext.setAttribute("posluziteljKorisniciAdresa", posluziteljKorisniciAdresa);
        
        String stranica = pbp.dajPostavku("stranica");
        servletContext.setAttribute("stranica", stranica);
    }
}
