/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.zrna;

import com.google.protobuf.TextFormat.ParseException;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.annotation.ManagedProperty;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.security.enterprise.authentication.mechanism.http.AutoApplySession;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.podaci.Dnevnik;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;

@Named(value = "pregledDnevnika")
@SessionScoped
public class PregledDnevnika implements Serializable {

    @Inject
    HttpServletRequest request;

    @Inject
    ServletContext context;

    @EJB
    PoslovnoPogledi poslovnaLogika;

    @Getter
    @Setter
    private String poruka;

    @Inject
    private Poruka beanPoruka;

    @Getter
    @Setter
    List<Dnevnik> zapisiDnevnika = new ArrayList<>();

    private String korisnik;
    private String lozinka;
    private String idSjednice;

    private static int pomak = 0;
    private int stranica;

    @Getter
    @Setter
    private String odVremena;
    @Getter
    @Setter
    private String doVremena;

    @PostConstruct
    public void prirpemiPodatke() {
        stranica = Integer.parseInt((String) context.getAttribute("stranica"));
    }

    public void ucitajZapise() {
        String odVremena;
        String doVremena;
        if (this.odVremena.equals("") || this.doVremena.equals("")) {
            odVremena = "";
            doVremena = "";
        } else {
            odVremena = pretvoriULong(this.odVremena, "dd.MM.yyyy HH:mm:ss");
            doVremena = pretvoriULong(this.doVremena, "dd.MM.yyyy HH:mm:ss");
            System.out.println("Vrijeme long : " + odVremena);
            System.out.println("Vrijeme long : " + doVremena);
        }
        List<Dnevnik> zapisiDnevnika = poslovnaLogika.dohvatiZapiseDnevnika(korisnik, lozinka, odVremena, doVremena,
                String.valueOf(pomak), String.valueOf(stranica));
        this.zapisiDnevnika = zapisiDnevnika;

        System.out.println(this.zapisiDnevnika);
    }

    public void dohvatiVrijeme() {
        System.out.println("Vrijeme pocetno : " + odVremena);
        ucitajZapise();
    }

    public void nazad() {
        if (pomak != 0) {
            pomak -= stranica;
        }
        ucitajZapise();
    }

    public void naprijed() {
        pomak += stranica;
        System.out.println("Od vremena" + odVremena);
        ucitajZapise();
    }

    public void dajPrvuStranicu() {
        pomak = 0;
        ucitajZapise();
    }

    public void dajPosljednjuStranicu() {
        String odVremena;
        String doVremena;
        if (this.odVremena.equals("") || this.doVremena.equals("")) {
            odVremena = "";
            doVremena = "";
        } else {
            odVremena = pretvoriULong(this.odVremena, "dd.MM.yyyy HH:mm:ss");
            doVremena = pretvoriULong(this.doVremena, "dd.MM.yyyy HH:mm:ss");
        }

        int brojZapisa = poslovnaLogika.dohvatiBrojZapisaDnevnika(odVremena, doVremena, korisnik, lozinka);
        int redniBrojStranice = brojZapisa / stranica;
        pomak = redniBrojStranice * stranica;
        ucitajZapise();
    }

    public String autoriziraj() {
        HttpSession sesija = request.getSession();
        korisnik = (String) sesija.getAttribute("korime");
        lozinka = (String) sesija.getAttribute("lozinka");
        idSjednice = (String) sesija.getAttribute("idSjednice");
        String autorizacija = poslovnaLogika.autorizirajKorisnika(korisnik, idSjednice, "pregledDnevnik");

        if (autorizacija.equals("ERROR")) {
            beanPoruka.setTekst("Korinsik nema dopuštenje !");
        } else {

            pomak = 0;
            odVremena = "";
            doVremena = "";

            ucitajZapise();
        }

        return autorizacija;
    }

    private String pretvoriULong(String datum, String uzorak) {
        try {
            SimpleDateFormat f = new SimpleDateFormat(uzorak);

            Date d = f.parse(datum);
            long milliseconds = d.getTime() + TimeUnit.HOURS.toMillis(2);

            return String.valueOf(milliseconds / 1000);
        } catch (java.text.ParseException ex) {
            Logger.getLogger(PregledDnevnika.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
}
