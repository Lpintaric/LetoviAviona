/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.zrna;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.annotation.ManagedProperty;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.Meteo;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.rest.podaci.AvionLeti;

@Named(value = "pregledAerodroma")
@SessionScoped
public class PregledAerodroma implements Serializable{

    @Inject
    HttpServletRequest request;

    @EJB
    PoslovnoPogledi poslovnoPogledi;

    @Getter
    @Setter
    private String poruka;

    @Inject
    private Poruka beanPoruka;

    @Getter
    @Setter
    List<Aerodrom> praceniAerodromi = new ArrayList<>();
    
    @Getter
    @Setter
    String icao;
    
    @Getter
    @Setter
    String dan;
    
    @Getter
    @Setter
    List<AvionLeti> letoviAerodroma = new ArrayList<>();
    
    @Getter
    @Setter
    List<Meteo> meteoPodaci = new ArrayList<>();
    

    private String korisnik;
    private String lozinka;
    private String idSjednice;
    
    @Getter
    @Setter
    private String prikazLetovi;
    @Getter
    @Setter
    private String prikazMeteoPodaci;
    @Getter
    @Setter
    private String prikazMeteoPodaciVrijeme;
    
    

    public void ucitajAerodrome() {
        
        praceniAerodromi = poslovnoPogledi.dohvatiPraceneAerodrome(korisnik, lozinka);

    }
    
    public void dohvatiLetoveAerodroma(){
        prikazLetovi = "true";
        prikazMeteoPodaci = "false";
        
        String dijelovi[] = dan.split("\\.");
        String formatiraniDatum = dijelovi[2] + "-" + dijelovi[1] + "-" + dijelovi[0];
//        "yyyy-MM-dd"
        letoviAerodroma = poslovnoPogledi.dohvatiLetoveAerodroma(korisnik, lozinka, icao, formatiraniDatum);
    }
    
    public void dohvatiMeteo(){
        prikazLetovi = "false";
        prikazMeteoPodaci = "true";
        
        String dijelovi[] = dan.split("\\.");
        String formatiraniDatum = dijelovi[2] + "-" + dijelovi[1] + "-" + dijelovi[0];
//        "yyyy-MM-dd"
        meteoPodaci = poslovnoPogledi.dohvatiMeteo(korisnik, lozinka, icao, formatiraniDatum);
    }
    
    public void dohvatiMeteoVrijeme(){
        prikazLetovi = "false";
        prikazMeteoPodaci = "true";
        
        String formatiraniDatum = dan;
//        "dd.MM.yyyy HH:mm:ss"
        Meteo m = poslovnoPogledi.dohvatiMeteoVrijeme(korisnik, lozinka, icao, formatiraniDatum);
        meteoPodaci = new ArrayList<>();
        meteoPodaci.add(m);
    }

    public String autoriziraj() {
        HttpSession sesija = request.getSession();
        korisnik = (String) sesija.getAttribute("korime");
        lozinka = (String) sesija.getAttribute("lozinka");
        idSjednice = (String) sesija.getAttribute("idSjednice");

        String autorizacija = poslovnoPogledi.autorizirajKorisnika(korisnik, idSjednice, "pregledAerodroma");

        if (autorizacija.equals("ERROR")) {
            beanPoruka.setTekst("Korinsik nema dopuštenje !");
        } else{
            ucitajAerodrome();
            prikazLetovi = "false";
            prikazMeteoPodaci = "false";
            prikazMeteoPodaciVrijeme = "false";
        }

        return autorizacija;
    }
}
