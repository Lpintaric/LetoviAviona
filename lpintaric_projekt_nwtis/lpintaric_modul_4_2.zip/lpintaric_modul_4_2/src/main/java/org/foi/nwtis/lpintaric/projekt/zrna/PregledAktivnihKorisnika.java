/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.zrna;

import com.google.protobuf.TextFormat.ParseException;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.annotation.ManagedProperty;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.security.enterprise.authentication.mechanism.http.AutoApplySession;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPoruke;
import org.foi.nwtis.lpintaric.projekt.podaci.Dnevnik;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.PrijavaKorisnika;

@Named(value = "pregledAktivnihKorisnika")
@SessionScoped
public class PregledAktivnihKorisnika implements Serializable {

    @Inject
    HttpServletRequest request;

    @Inject
    ServletContext context;

    @EJB
    PoslovnoPoruke poslovnoPoruke;
    
    @EJB
    PoslovnoPogledi poslovnoPogledi;

    @Getter
    @Setter
    private String poruka;

    @Inject
    private Poruka beanPoruka;

    @Getter
    @Setter
    List<PrijavaKorisnika> prijaveKorsinika = new ArrayList<>();

    private String korisnik;
    private String lozinka;
    private String idSjednice;


    @PostConstruct
    public void prirpemiPodatke() {
    }

    public void ucitajPrijave() {
        List<PrijavaKorisnika> prijaveKorsinika = poslovnoPoruke.dohvatiSvePrijave();
        this.prijaveKorsinika = prijaveKorsinika;
    }


    public String autoriziraj() {
        HttpSession sesija = request.getSession();
        korisnik = (String) sesija.getAttribute("korime");
        lozinka = (String) sesija.getAttribute("lozinka");
        idSjednice = (String) sesija.getAttribute("idSjednice");
        String autorizacija = poslovnoPogledi.autorizirajKorisnika(korisnik, idSjednice, "pregledAktivnihKorisnika");

        if (autorizacija.equals("ERROR")) {
            beanPoruka.setTekst("Korisnik nema dopuštenje !");
        } else{
            ucitajPrijave();
        }
        
        return autorizacija;
    }
    
    public void osvjeziListuPrijava(){
        ucitajPrijave();
    }

    private String pretvoriULong(String datum, String uzorak) {
        try {
            SimpleDateFormat f = new SimpleDateFormat(uzorak);
            
            Date d = f.parse(datum);
            long milliseconds = d.getTime() + TimeUnit.HOURS.toMillis(2);
            
            return String.valueOf(milliseconds / 1000);
        } catch (java.text.ParseException ex) {
            Logger.getLogger(PregledAktivnihKorisnika.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
}
