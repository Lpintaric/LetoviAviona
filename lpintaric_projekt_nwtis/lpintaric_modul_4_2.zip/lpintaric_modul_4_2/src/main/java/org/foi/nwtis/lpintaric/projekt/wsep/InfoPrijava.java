package org.foi.nwtis.lpintaric.projekt.wsep;

import jakarta.ejb.EJB;
import jakarta.websocket.EndpointConfig;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPoruke;
import org.foi.nwtis.lpintaric.projekt.podaci.PrijavaKorisnika;

@ServerEndpoint("/login")
public class InfoPrijava {

    @EJB
    PoslovnoPoruke poslovnoPoruke;

    @OnMessage
    public void stiglaPoruka(String message, Session session) {
        System.out.println("Stigla poruka : " + message);
        String[] dijeloviPoruke = message.split(";");
        if (dijeloviPoruke[0].equals("PRIJAVA")) {
            String korisnik = dijeloviPoruke[1];
            String aplikacija = dijeloviPoruke[2];
            String vrijemePrijave = dijeloviPoruke[3];

            PrijavaKorisnika p = new PrijavaKorisnika(korisnik, aplikacija, vrijemePrijave);
            poslovnoPoruke.dodajPrijavu(p);
        } else if (dijeloviPoruke[0].equals("ODJAVA")) {
            String korisnik = dijeloviPoruke[1];
            String aplikacija = dijeloviPoruke[2];
            poslovnoPoruke.obrisiPrijavu(korisnik, aplikacija);
        }

        for (Session sess : session.getOpenSessions()) {
            if (sess.isOpen()) {
                try {
                    sess.getBasicRemote().sendText("REFRESH");
                } catch (IOException ex) {
                    Logger.getLogger(InfoPrijava.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }
}
