/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.wsep;

import jakarta.annotation.PostConstruct;
import jakarta.websocket.ClientEndpoint;
import jakarta.websocket.ContainerProvider;
import jakarta.websocket.DeploymentException;
import jakarta.websocket.OnMessage;
import jakarta.websocket.Session;
import jakarta.websocket.WebSocketContainer;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;

@ClientEndpoint()
public class OglasnikPrijava {
    private Session session;
    
    @PostConstruct
    public void spajanje() {
        String uri = "ws://localhost:8380/lpintaric_modul_4_2/login";
        try {
            WebSocketContainer container = ContainerProvider.getWebSocketContainer();
            session = container.connectToServer(this, new URI(uri));
        } catch (IOException | URISyntaxException | DeploymentException ex) {
            Logger.getLogger(OglasnikPrijava.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @OnMessage
    public void onMessage(String message){
        
    }
        
    public void posaljiPoruku(String poruka){
        try {
            session.getBasicRemote().sendText(poruka);
        } catch (IOException ex) {
            Logger.getLogger(OglasnikPrijava.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
