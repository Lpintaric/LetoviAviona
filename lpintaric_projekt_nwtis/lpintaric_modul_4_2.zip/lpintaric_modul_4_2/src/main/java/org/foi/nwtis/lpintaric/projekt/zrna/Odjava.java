/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.zrna;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.Getter;
import lombok.Setter;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.wsep.OglasnikPrijava;

@Named(value = "odjava")
@RequestScoped
public class Odjava {
    @Inject
    HttpServletRequest request;
    
    @EJB
    PoslovnoPogledi poslovnaLogika;
    
    @Getter
    @Setter
    private String poruka;
    
    @Inject
    OglasnikPrijava oglasnikPrijava;
    
    public String odjaviKorisnika(){
        HttpSession sesija = request.getSession();
        String idSjednice = (String)sesija.getAttribute("idSjednice");
        String korisnik = (String)sesija.getAttribute("korime");
        
        String odgovor = poslovnaLogika.odjaviKorisnika(korisnik, idSjednice);
        
        sesija.removeAttribute("idSjednice");
        sesija.removeAttribute("korime");
        
        String poruka = "ODJAVA;" + korisnik + ";lpintaric_aplikacija_4";
        oglasnikPrijava.posaljiPoruku(poruka);
        
        setPoruka("Uspješna odjava !");
        
        return "OK";
    }
}
