/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.zrna;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.annotation.ManagedProperty;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;

@Named(value = "pregledKorisnika")
@RequestScoped
public class PregledKorisnika {

    @Inject
    HttpServletRequest request;

    @EJB
    PoslovnoPogledi poslovnaLogika;

    @Getter
    @Setter
    private String poruka;

    @Inject
    private Poruka beanPoruka;

    @Getter
    @Setter
    List<Korisnik> korisnici = new ArrayList<>();

    private String korisnik;
    private String lozinka;
    private String idSjednice;

    public void setUserInf(Poruka beanPoruka) {
        this.beanPoruka = beanPoruka;
    }

    public void ucitajKorisnike() {
        korisnici = poslovnaLogika.dohvatiKorisnike(korisnik, lozinka);

    }

    public String autoriziraj() {
        HttpSession sesija = request.getSession();
        korisnik = (String) sesija.getAttribute("korime");
        lozinka = (String) sesija.getAttribute("lozinka");
        idSjednice = (String) sesija.getAttribute("idSjednice");

        String autorizacija = poslovnaLogika.autorizirajKorisnika(korisnik, idSjednice, "pregledKorisnik");

        if (autorizacija.equals("ERROR")) {
            beanPoruka.setTekst("Korinsik nema dopuštenje !");
        }
        
        ucitajKorisnike();

        return autorizacija;
    }
}
