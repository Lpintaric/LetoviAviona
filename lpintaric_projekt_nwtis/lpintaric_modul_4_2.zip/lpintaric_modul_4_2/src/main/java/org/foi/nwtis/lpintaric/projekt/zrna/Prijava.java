package org.foi.nwtis.lpintaric.projekt.zrna;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import org.foi.nwtis.lpintaric.projekt.ejb.sb.PoslovnoPogledi;
import org.foi.nwtis.lpintaric.projekt.wsep.OglasnikPrijava;

@Named(value = "prijava")
@RequestScoped
public class Prijava {

    @Getter
    @Setter
    private String korisnik;

    @Getter
    @Setter
    private String lozinka;

    @Getter
    @Setter
    private String poruka;

    @EJB
    PoslovnoPogledi poslovnaLogika;

    @Inject
    HttpServletRequest request;

    @Inject
    OglasnikPrijava oglasnikPrijava;

    public Prijava() {
    }

    public String validirajPrijavu() {
        String odgovor = poslovnaLogika.autenticirajKorisnika(korisnik, lozinka);
        if (odgovor != "ERROR") {
            String[] dijeloviOdgovora = odgovor.split(" ");

            HttpSession sesija = request.getSession(false);
            String idSjednice = dijeloviOdgovora[1];
            sesija.setAttribute("idSjednice", idSjednice);
            sesija.setAttribute("korime", korisnik);
            sesija.setAttribute("lozinka", lozinka);

            String poruka = "PRIJAVA;" + korisnik + ";lpintaric_aplikacija_4;" + dohvatiVrijeme();
            oglasnikPrijava.posaljiPoruku(poruka);

            return "OK";
        } else {
            setPoruka("Pogrešni podaci za prijavu !");
            return "ERROR";
        }
    }
    
    private String dohvatiVrijeme() {
        SimpleDateFormat formater = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        Date trenutnoVrijeme = new Date();
        String vrijemeZahtjeva = formater.format(trenutnoVrijeme);
        return vrijemeZahtjeva;
    }

}
