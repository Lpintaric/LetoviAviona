package org.foi.nwtis.lpintaric.projekt.ejb.sb;

import jakarta.ejb.EJB;
import jakarta.ejb.Stateful;
import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.podaci.PrijavaKorisnika;

@Stateful
public class PoslovnoPoruke {
    @Inject
    ServletContext context;
    
    @EJB
    Baza baza;
    
    public void dodajPrijavu(PrijavaKorisnika p){
        baza.dodajPrijavu(p);
    }
    
    public void obrisiPrijavu(String korisnik, String aplikacija){
        baza.obrisiPrijavu(korisnik, aplikacija);
    }
    
    public List<PrijavaKorisnika> dohvatiSvePrijave(){
        return baza.getAktivnePrijave();
    }
    
}
