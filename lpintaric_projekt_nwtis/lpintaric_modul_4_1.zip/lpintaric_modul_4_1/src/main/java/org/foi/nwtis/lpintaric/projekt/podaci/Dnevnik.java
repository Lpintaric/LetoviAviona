package org.foi.nwtis.lpintaric.projekt.podaci;

import java.io.Serializable;

public class Dnevnik implements Serializable{
    private String korisnik;
    private long vrijemePrimitkaKomande;
    private String sadrzajKomande;
    private String statusOdgvovora;

    public Dnevnik() {
    }
    
    public Dnevnik(String korisnik, long vrijemePrimitkaKomande, String sadrzajKomande, String statusOdgvovora) {
        this.korisnik = korisnik;
        this.vrijemePrimitkaKomande = vrijemePrimitkaKomande;
        this.sadrzajKomande = sadrzajKomande;
        this.statusOdgvovora = statusOdgvovora;
    }

    public String getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    public long getVrijemePrimitkaKomande() {
        return vrijemePrimitkaKomande;
    }

    public void setVrijemePrimitkaKomande(long vrijemePrimitkaKomande) {
        this.vrijemePrimitkaKomande = vrijemePrimitkaKomande;
    }

    public String getSadrzajKomande() {
        return sadrzajKomande;
    }

    public void setSadrzajKomande(String sadrzajKomande) {
        this.sadrzajKomande = sadrzajKomande;
    }

    public String getStatusOdgvovora() {
        return statusOdgvovora;
    }

    public void setStatusOdgvovora(String statusOdgvovora) {
        this.statusOdgvovora = statusOdgvovora;
    }
    
    
}
