/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.ejb.sb;

import com.google.gson.Gson;
import jakarta.ejb.Stateful;
import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_3;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_5;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_6;
import org.foi.nwtis.lpintaric.projekt.podaci.Dnevnik;
import org.foi.nwtis.lpintaric.projekt.podaci.DnevnikKlijent_2;
import org.foi.nwtis.lpintaric.projekt.podaci.DnevnikKlijent_3;
import org.foi.nwtis.lpintaric.projekt.podaci.KorisniciKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.Meteo;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_3;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.rest.podaci.AvionLeti;

@Stateful
public class PoslovnoPogledi {

    @Inject
    ServletContext context;

    public String autenticirajKorisnika(String korisnik, String lozinka) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            return odgovor;
        } else {
            return "ERROR";
        }
    }

    public String odjaviKorisnika(String korisnik, String idSjednice) {
        String komanda = "LOGOUT " + korisnik + " " + idSjednice;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            return odgovor;
        } else {
            return "ERROR";
        }

    }

    public List<Korisnik> dohvatiKorisnike(String korisnik, String lozinka) {
        KorisniciKlijent_1 kk1 = new KorisniciKlijent_1();
        Response r1 = kk1.dajKorisnike(Response.class, korisnik, lozinka);
        if (r1.getStatusInfo().toString().equals("OK")) {
            Korisnik[] k = new Gson().fromJson(r1.readEntity(String.class), Korisnik[].class);
            List<Korisnik> korisnici = new ArrayList<>(Arrays.asList(k));
            return korisnici;
        } else {
            return null;
        }
    }

    public String autorizirajKorisnika(String korisnik, String idSjednice, String podrucje) {
        String komanda = "AUTHOR " + korisnik + " " + idSjednice + " " + podrucje;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            return "OK";
        } else {
            return "ERROR";
        }
    }

    public List<Dnevnik> dohvatiZapiseDnevnika(String korisnik, String lozinka, String odVremena, String doVremena,
            String pomak, String stranica) {
        DnevnikKlijent_2 dk2 = new DnevnikKlijent_2(korisnik);
        Response r1 = dk2.dohvatiZapiseZaKorisnika(Response.class, odVremena, doVremena, pomak, stranica, korisnik, lozinka);
        if (r1.getStatusInfo().toString().equals("OK")) {
            Dnevnik[] d = new Gson().fromJson(r1.readEntity(String.class), Dnevnik[].class);
            List<Dnevnik> zapisiDnevnika = new ArrayList<>(Arrays.asList(d));
            return zapisiDnevnika;
        } else {
            return null;
        }
    }

    public int dohvatiBrojZapisaDnevnika(String odVremena, String doVremena, String korisnik, String lozinka) {
        DnevnikKlijent_3 dk3 = new DnevnikKlijent_3(korisnik);
        Response r = dk3.dohvatiBrojZapisaZaKorisnika(Response.class, odVremena, doVremena, korisnik, lozinka);
        if (r.getStatusInfo().toString().equals("OK")) {
            int broj = new Gson().fromJson(r.readEntity(String.class), Integer.class);
            return broj;
        } else {
            return 0;
        }
    }

    public List<Aerodrom> dohvatiPraceneAerodrome(String korisnik, String lozinka) {
        MojiAerodromiKlijent_3 mak3 = new MojiAerodromiKlijent_3(korisnik);
        Response r = mak3.dohvatiAerodromeKojePratiKorisnik(Response.class, korisnik, lozinka);
        if (r.getStatusInfo().toString().equals("OK")) {
            Aerodrom[] a = new Gson().fromJson(r.readEntity(String.class), Aerodrom[].class);
            List<Aerodrom> aerodromi = new ArrayList<>(Arrays.asList(a));
            return aerodromi;
        } else {
            return null;
        }
    }

    public List<AvionLeti> dohvatiLetoveAerodroma(String korisnik, String lozinka, String icao, String dan) {
        AerodromiKlijent_3 ak3 = new AerodromiKlijent_3(icao, dan);
        Response r = ak3.dohvatiLetoveAerodromaZaDan(Response.class, korisnik, lozinka);
        if (r.getStatusInfo().toString().equals("OK")) {
            AvionLeti[] a = new Gson().fromJson(r.readEntity(String.class), AvionLeti[].class);
            List<AvionLeti> letovi = new ArrayList<>(Arrays.asList(a));
            return letovi;
        } else {
            return null;
        }
    }

    public List<Meteo> dohvatiMeteo(String korisnik, String lozinka, String icao, String dan) {
        AerodromiKlijent_5 ak5 = new AerodromiKlijent_5(icao, dan);
        Response r = ak5.dohvatiMeteoPodatkeAerodromaZaDan(Response.class, korisnik, lozinka);
        if (r.getStatusInfo().toString().equals("OK")) {
            Meteo[] m = new Gson().fromJson(r.readEntity(String.class), Meteo[].class);
            List<Meteo> meteoPodaci = new ArrayList<>(Arrays.asList(m));
            return meteoPodaci;
        } else {
            return null;
        }
    }

    public Meteo dohvatiMeteoVrijeme(String korisnik, String lozinka, String icao, String vrijeme) {
        String formVrijeme = pretvoriULong(vrijeme, "dd.MM.yyyy HH:mm:ss");
        System.out.println(formVrijeme);
        AerodromiKlijent_6 ak6 = new AerodromiKlijent_6(icao, formVrijeme);
        Response r = ak6.dohvatiMeteoPodatkeAerodromaZaVrijeme(Response.class, korisnik, lozinka);
        if (r.getStatusInfo().toString().equals("OK")) {
            Meteo m = new Gson().fromJson(r.readEntity(String.class), Meteo.class);
            return m;
        } else {
            return null;
        }
    }

    private String pretvoriULong(String datum, String uzorak) {
        SimpleDateFormat formatter = new SimpleDateFormat(uzorak);
        Date date;
        try {
            date = (Date) formatter.parse(datum);
            long mills = date.getTime() + TimeUnit.HOURS.toMillis(2);
            return String.valueOf(mills/1000);
        } catch (ParseException ex) {
            Logger.getLogger(PoslovnoPogledi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspješno spajanje na serversku utičnicu !";
        }
    }
}
