package org.foi.nwtis.lpintaric.projekt.podaci;

public class PrijavaKorisnika {
    private String korisnik;
    private String aplikacija;
    private String vrijemePrijave;

    public PrijavaKorisnika(String korisnik, String aplikacija, String vrijemePrijave) {
        this.korisnik = korisnik;
        this.aplikacija = aplikacija;
        this.vrijemePrijave = vrijemePrijave;
    }

    public String getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    public String getAplikacija() {
        return aplikacija;
    }

    public void setAplikacija(String aplikacija) {
        this.aplikacija = aplikacija;
    }

    public String getVrijemePrijave() {
        return vrijemePrijave;
    }

    public void setVrijemePrijave(String vrijemePrijave) {
        this.vrijemePrijave = vrijemePrijave;
    }
    
    
}
