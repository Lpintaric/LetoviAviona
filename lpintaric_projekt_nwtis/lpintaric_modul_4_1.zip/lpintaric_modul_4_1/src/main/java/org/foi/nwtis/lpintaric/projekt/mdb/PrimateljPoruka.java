/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.mdb;

import jakarta.ejb.MessageDriven;
import jakarta.inject.Inject;
import jakarta.jms.JMSConnectionFactory;
import jakarta.jms.JMSContext;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;
import java.util.logging.Level;
import java.util.logging.Logger;

@MessageDriven(mappedName = "jms/NWTiS_DZ3")
public class PrimateljPoruka implements MessageListener {

    @Inject
    @JMSConnectionFactory("jms/NWTiS_QF_DZ3")
    private JMSContext context;
    
    public void onMessage(Message msg) {
        String text;
        try {
            text = ((TextMessage) msg).getText();
            System.out.println("Primatelj poruka: '" + text + "'");
//            oglasnikAerodroma.posaljiPoruku(text);
        } catch (JMSException ex) {
            Logger.getLogger(PrimateljPoruka.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
