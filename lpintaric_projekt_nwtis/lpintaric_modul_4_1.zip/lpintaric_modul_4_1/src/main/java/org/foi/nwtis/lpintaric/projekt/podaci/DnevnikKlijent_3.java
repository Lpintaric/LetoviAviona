/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.podaci;

/**
 * Jersey REST client generated for REST resource:dnevnik [dnevnik/{korisnik}/broj]<br>
 * USAGE:
 * <pre>
 *        DnevnikKlijent_3 client = new DnevnikKlijent_3();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author lukap
 */
public class DnevnikKlijent_3 {

    private jakarta.ws.rs.client.WebTarget webTarget;
    private jakarta.ws.rs.client.Client client;
    private static final String BASE_URI = "http://localhost:8084/lpintaric_aplikacija_2/rest/";

    public DnevnikKlijent_3(String korisnik) {
        client = jakarta.ws.rs.client.ClientBuilder.newClient();
        String resourcePath = java.text.MessageFormat.format("dnevnik/{0}/broj", new Object[]{korisnik});
        webTarget = client.target(BASE_URI).path(resourcePath);
    }

    public void setResourcePath(String korisnik) {
        String resourcePath = java.text.MessageFormat.format("dnevnik/{0}/broj", new Object[]{korisnik});
        webTarget = client.target(BASE_URI).path(resourcePath);
    }

    /**
     * @param responseType Class representing the response
     * @param odVremena query parameter
     * @param doVremena query parameter
     * @return response object (instance of responseType class)@param korisnik header parameter[REQUIRED]
     * @param lozinka header parameter[REQUIRED]
     */
    public <T> T dohvatiBrojZapisaZaKorisnika(Class<T> responseType, String odVremena, String doVremena, String korisnik, String lozinka) throws jakarta.ws.rs.ClientErrorException {
        String[] queryParamNames = new String[]{"odVremena", "doVremena"};
        String[] queryParamValues = new String[]{odVremena, doVremena};
        ;
        jakarta.ws.rs.core.Form form = getQueryOrFormParams(queryParamNames, queryParamValues);
        jakarta.ws.rs.core.MultivaluedMap<String, String> map = form.asMap();
        for (java.util.Map.Entry<String, java.util.List<String>> entry : map.entrySet()) {
            java.util.List<String> list = entry.getValue();
            String[] values = list.toArray(new String[list.size()]);
            webTarget = webTarget.queryParam(entry.getKey(), (Object[]) values);
        }
        return webTarget.request(jakarta.ws.rs.core.MediaType.APPLICATION_JSON).header("korisnik", korisnik).header("lozinka", lozinka).get(responseType);
    }

    private jakarta.ws.rs.core.Form getQueryOrFormParams(String[] paramNames, String[] paramValues) {
        jakarta.ws.rs.core.Form form = new jakarta.ws.rs.core.Form();
        for (int i = 0; i < paramNames.length; i++) {
            if (paramValues[i] != null) {
                form = form.param(paramNames[i], paramValues[i]);
            }
        }
        return form;
    }

    public void close() {
        client.close();
    }
    
}
