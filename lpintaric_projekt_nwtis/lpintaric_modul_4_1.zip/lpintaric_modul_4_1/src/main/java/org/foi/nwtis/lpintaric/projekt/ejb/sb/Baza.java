package org.foi.nwtis.lpintaric.projekt.ejb.sb;

import jakarta.ejb.EJB;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import org.foi.nwtis.lpintaric.projekt.podaci.PrijavaKorisnika;

@Startup 
@Singleton
public class Baza {
    @Getter
    private List<PrijavaKorisnika> aktivnePrijave = new ArrayList<>();
    
    public void dodajPrijavu(PrijavaKorisnika p){
        aktivnePrijave.add(p);
    }
    
    public void obrisiPrijavu(String korisnik, String aplikacija){
        PrijavaKorisnika pk = aktivnePrijave.stream().filter(x
                        -> x.getKorisnik().equals(korisnik)
                        && (x.getAplikacija().equals(aplikacija))
                ).findAny().orElse(null);
        
        int index = aktivnePrijave.indexOf(pk);
        aktivnePrijave.remove(index);
        
    }
    
}
