package org.foi.nwtis.lpintaric.projekt.podaci;

import java.io.Serializable;

public class Korisnik implements Serializable{
    private String korime;
    private String lozinka;
    private String prezime;
    private String ime;

    public Korisnik() {
    }
    
    public Korisnik(String korime, String lozinka, String prezime, String ime) {
        this.korime = korime;
        this.lozinka = lozinka;
        this.prezime = prezime;
        this.ime = ime;
    }

    public String getKorime() {
        return korime;
    }

    public void setKorime(String korime) {
        this.korime = korime;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }
    
    
}
