package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Airport;
import org.foi.nwtis.podaci.Korisnik;
import org.foi.nwtis.rest.podaci.Lokacija;

public class MyAirportsDAO {

    public List<String> dohvatiOznakeSvihAerodroma(PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT IDENT FROM MYAIRPORTS GROUP BY IDENT";
        List<String> idents = new ArrayList<>();

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    PreparedStatement s = con.prepareStatement(upit)) {

                ResultSet rs = s.executeQuery();

                while (rs.next()) {
                    String ident = rs.getString("IDENT");
                    idents.add(ident);
                }
                return idents;
            } catch (SQLException ex) {
                Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public List<MyAirport> dohvatiPracenjaAerodroma(String icao, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * FROM MYAIRPORTS WHERE IDENT = ?";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            List<MyAirport> pracenja = new ArrayList<>();

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, icao);
                ResultSet rs = s.executeQuery();

                while (rs.next()) {
                    int id = rs.getInt("id");
                    String ident = rs.getString("ident");
                    String username = rs.getString("username");
                    Timestamp stored = rs.getTimestamp("stored");
                    MyAirport k = new MyAirport(id, ident, username, stored);

                    pracenja.add(k);
                }
                return pracenja;

            } catch (SQLException ex) {
                Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public List<Aerodrom> dohvatiAerodromeKojePratiKorisnik(String korisnik, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT A.IDENT, A.NAME, A.ISO_COUNTRY, A.COORDINATES FROM AIRPORTS A LEFT JOIN "
                + "MYAIRPORTS MA ON A.IDENT = MA.IDENT "
                + "WHERE MA.USERNAME = ?";

        try {
            Class.forName(pbp.getDriverDatabase(url));
            List<Aerodrom> aerodromi = new ArrayList<>();
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, korisnik);

                ResultSet rs = s.executeQuery();

                while (rs.next()) {
                    String icao = rs.getString("IDENT");
                    String naziv = rs.getString("NAME");
                    String drzava = rs.getString("ISO_COUNTRY");
                    String koordinate = rs.getString("COORDINATES");
                    koordinate = koordinate.replaceAll("\\s", "");
                    String[] razdvojeneKoordinate = koordinate.split(",");
                    Lokacija lokacija = new Lokacija(razdvojeneKoordinate[1], razdvojeneKoordinate[0]);
                    
                    Aerodrom a = new Aerodrom(icao, naziv, drzava, lokacija);

                    aerodromi.add(a);
                }
                return aerodromi;

            } catch (SQLException ex) {
                Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean dodajAerodromUListuPracenih(String korisnik ,Aerodrom aerodrom, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "INSERT INTO MYAIRPORTS (IDENT, USERNAME, STORED) VALUES (?, ?, CURRENT_TIMESTAMP)";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                     PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, aerodrom.getIcao());
                s.setString(2, korisnik);

                int brojAzuriranja = s.executeUpdate();

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean obrisiAerodromIzListePracenih(String korisnik, String icao , PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "DELETE FROM MYAIRPORTS WHERE USERNAME = ? AND IDENT = ?";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                     PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, korisnik);
                s.setString(2, icao);

                int brojAzuriranja = s.executeUpdate();

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyAirportsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
