package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.rest.podaci.AvionLeti;
import org.foi.nwtis.rest.podaci.MeteoOriginal;

public class MeteoDAO {
    public boolean dodajMeteo(Meteo m, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "INSERT INTO meteo (icao, vrijeme, temperatura, temperatura_jedinica,"
                + " vlaga, vlaga_jedinica, tlak, tlak_jedinica, brzina_vjetra, brzina_vjetra_naziv, "
                + " smjer_vjetra, smjer_vjetra_naziv) "
                + "VALUES ('" + m.getIcao() + "', " + m.getVrijeme() + ", " + m.getTemperatura() + ", '" + m.getTemperatura_jedinica()
                +  "', " + m.getVlaga() +  ", '" + m.getVlaga_jedinica()+ "', " + m.getTlak() + ", '" + m.getTlak_jedinica()
                + "', " + m.getBrzina_vjetra() + ", '" + m.getBrzina_vjetra_naziv()+ "', " + m.getSmjer_vjetra() +  ", '" + m.getSmjer_vjetra_naziv() + "')";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                int brojAzuriranja = s.executeUpdate(upit);

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public List<Meteo> dohvatiMeteoPodatkeAerodromaZaDan(String icao, long dan, PostavkeBazaPodataka pbp){
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        long pocetnoVrijeme = dan;
        long zavrsnoVrijeme = dan + TimeUnit.DAYS.toMillis(1)/1000;
        String upit = "SELECT * FROM meteo WHERE icao = '" + icao + "'"
                + " AND vrijeme > " + pocetnoVrijeme
                + " AND vrijeme < " + zavrsnoVrijeme;
        
         try {
            Class.forName(pbp.getDriverDatabase(url));
            List<Meteo> meteoPodaci = new ArrayList<>();
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    String icao1 = rs.getString("icao");
                    int vrijeme = rs.getInt("vrijeme");
                    float temperatura = rs.getFloat("temperatura");
                    String temperatura_jedinica = rs.getString("temperatura_jedinica");
                    float vlaga = rs.getFloat("vlaga");
                    String vlaga_jedinica = rs.getString("vlaga_jedinica");
                    float tlak = rs.getFloat("tlak");
                    String tlak_jedinica = rs.getString("tlak_jedinica");
                    float brzina_vjetra = rs.getFloat("brzina_vjetra");
                    String brzina_vjetra_naziv = rs.getString("brzina_vjetra_naziv");
                    int smjer_vjetra = rs.getInt("smjer_vjetra");
                    String smjer_vjetra_naziv = rs.getString("smjer_vjetra_naziv");

                    Meteo m1 = new Meteo(icao1, vrijeme, temperatura, temperatura_jedinica, vlaga, vlaga_jedinica, tlak, tlak_jedinica, 
                            brzina_vjetra, brzina_vjetra_naziv, smjer_vjetra, smjer_vjetra_naziv);
                    meteoPodaci.add(m1);
                }
                return meteoPodaci;
            } catch (SQLException ex) {
                Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public Meteo dohvatiMeteoPodatkeAerodromaZaVrijeme(String icao, long vrijeme, PostavkeBazaPodataka pbp){
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();

        String upit = "SELECT * FROM meteo WHERE icao = '" + icao + "'"
                + " AND vrijeme > " + vrijeme
                + " ORDER BY vrijeme ASC LIMIT 1";
        
         try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    String icao1 = rs.getString("icao");
                    int vrijeme1 = rs.getInt("vrijeme");
                    float temperatura = rs.getFloat("temperatura");
                    String temperatura_jedinica = rs.getString("temperatura_jedinica");
                    float vlaga = rs.getFloat("vlaga");
                    String vlaga_jedinica = rs.getString("vlaga_jedinica");
                    float tlak = rs.getFloat("tlak");
                    String tlak_jedinica = rs.getString("tlak_jedinica");
                    float brzina_vjetra = rs.getFloat("brzina_vjetra");
                    String brzina_vjetra_naziv = rs.getString("brzina_vjetra_naziv");
                    int smjer_vjetra = rs.getInt("smjer_vjetra");
                    String smjer_vjetra_naziv = rs.getString("smjer_vjetra_naziv");

                    Meteo m1 = new Meteo(icao1, vrijeme1, temperatura, temperatura_jedinica, vlaga, vlaga_jedinica, tlak, tlak_jedinica, 
                            brzina_vjetra, brzina_vjetra_naziv, smjer_vjetra, smjer_vjetra_naziv);
                    return m1;
                }
            } catch (SQLException ex) {
                Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public Meteo dohvatiPosljednjiMeteo(PostavkeBazaPodataka pbp){
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();

        String upit = "SELECT * FROM meteo ORDER BY vrijeme DESC LIMIT 1";
        
         try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    String icao1 = rs.getString("icao");
                    int vrijeme1 = rs.getInt("vrijeme");
                    float temperatura = rs.getFloat("temperatura");
                    String temperatura_jedinica = rs.getString("temperatura_jedinica");
                    float vlaga = rs.getFloat("vlaga");
                    String vlaga_jedinica = rs.getString("vlaga_jedinica");
                    float tlak = rs.getFloat("tlak");
                    String tlak_jedinica = rs.getString("tlak_jedinica");
                    float brzina_vjetra = rs.getFloat("brzina_vjetra");
                    String brzina_vjetra_naziv = rs.getString("brzina_vjetra_naziv");
                    int smjer_vjetra = rs.getInt("smjer_vjetra");
                    String smjer_vjetra_naziv = rs.getString("smjer_vjetra_naziv");

                    Meteo m1 = new Meteo(icao1, vrijeme1, temperatura, temperatura_jedinica, vlaga, vlaga_jedinica, tlak, tlak_jedinica, 
                            brzina_vjetra, brzina_vjetra_naziv, smjer_vjetra, smjer_vjetra_naziv);
                    return m1;
                }
            } catch (SQLException ex) {
                Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MeteoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
