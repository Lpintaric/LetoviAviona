package org.foi.nwtis.lpintaric.projekt.rest;

import com.mysql.cj.Query;
import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.projekt.podaci.AirplanesDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.AirportDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.Meteo;
import org.foi.nwtis.lpintaric.projekt.podaci.MeteoDAO;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Airport;
import org.foi.nwtis.podaci.Korisnik;
import org.foi.nwtis.rest.podaci.AvionLeti;

@Path("aerodromi")
public class AerodromiResource {

    @Inject
    ServletContext context;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dajAerodrome(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @QueryParam("naziv") String naziv,
            @QueryParam("drzava") String drzava) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        AirportDAO adao = new AirportDAO();
        List<Aerodrom> aerodromi = adao.dohvatiSveAerodrome(naziv, drzava, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(aerodromi)
                .build();
    }

    @Path("{icao}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiAerodrom(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("icao") String icao) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        AirportDAO adao = new AirportDAO();
        Aerodrom trazeniAerodrom = adao.dohvatiAerodromPremaIcao(icao, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(trazeniAerodrom)
                .build();
    }
    
    @Path("{icao}/letovi")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiBrojLetovaZaAerodrom(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("icao") String icao) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        AirplanesDAO adao = new AirplanesDAO();
        int brojLetova = adao.dohvatiBrojLetovaZaAerodrom(icao, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(brojLetova)
                .build();
    }
    
    @Path("{icao}/letovi/{dan}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiLetoveAerodromaZaDan(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("icao") String icao,
            @PathParam("dan") String dan) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }
        
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        AirplanesDAO adao = new AirplanesDAO();
        long danLong = pretvoriULong(dan, "yyyy-MM-dd");
        List<AvionLeti> letovi = adao.dohvatiLetoveAerodromaZaDan(icao, danLong, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(letovi)
                .build();
    }
    
    @Path("{icao}/meteoDan/{dan}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiMeteoPodatkeAerodromaZaDan(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("icao") String icao,
            @PathParam("dan") String dan) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }
        
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        MeteoDAO mdao = new MeteoDAO();
        long danLong = pretvoriULong(dan, "yyyy-MM-dd");
        List<Meteo> meteoPodaci = mdao.dohvatiMeteoPodatkeAerodromaZaDan(icao, danLong, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(meteoPodaci)
                .build();
    }
    
    @Path("{icao}/meteoVrijeme/{vrijeme}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiMeteoPodatkeAerodromaZaVrijeme(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("icao") String icao,
            @PathParam("vrijeme") String vrijeme) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        MeteoDAO mdao = new MeteoDAO();
        long vrijemeLong = Long.parseLong(vrijeme);
        Meteo meteoPodatak = mdao.dohvatiMeteoPodatkeAerodromaZaVrijeme(icao, vrijemeLong, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(meteoPodatak)
                .build();
    }
    
    
    
    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspješno spajanje na serversku utičnicu !";
        }
    }
    
    private long pretvoriULong(String datum, String uzorak) {
        DateTimeFormatter dateFormatter
                = DateTimeFormatter.ofPattern(uzorak, Locale.ENGLISH);
        long milisekunde = LocalDate.parse(datum, dateFormatter)
                .atStartOfDay(ZoneOffset.UTC)
                .toInstant()
                .toEpochMilli();
        return milisekunde / 1000;
    }
}
