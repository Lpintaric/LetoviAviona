package org.foi.nwtis.lpintaric.projekt.rest;

import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;

@Path("korisnici")
public class KorisniciResource {

    @Inject
    ServletContext context;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dajKorisnike(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Korisnik za ulazne podatke ne postoji !")
                    .build();
        }
        
        String idSjednice = dijeloviOdgovora[1];
        String komanda2 = "LISTALL " + korisnik + " " + idSjednice;
        String odgovor2 = posaljiKomanduNaPosluziteljKorisnika(komanda2);
        String[] dijeloviOdgovora2 = odgovor2.split(" ");
        if (dijeloviOdgovora2[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity(odgovor)
                    .build();
        }
        List<Korisnik> korisnici = new ArrayList<>();
        for (int i = 1; i < dijeloviOdgovora2.length; i++) {
            String korisnikString = dijeloviOdgovora2[i];
            korisnikString = korisnikString.replace("\"", "");
            if(i == 1){
                System.out.println(korisnikString);
            }
            String[] korisnikStringDijelovi = korisnikString.split("\t");
            Korisnik k1 = new Korisnik(korisnikStringDijelovi[0], "******",
                    korisnikStringDijelovi[1], korisnikStringDijelovi[2]);
            korisnici.add(k1);
        }
        
        return Response
                .status(Response.Status.OK)
                .entity(korisnici)
                .build();
    }

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response dodajKorisnika(Korisnik noviKorisnik) {
        String komanda = "ADD " + noviKorisnik.getKorime() + " " + noviKorisnik.getLozinka() 
                + " \"" + noviKorisnik.getPrezime()+ "\" \"" + noviKorisnik.getIme() + "\"";
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity(odgovor)
                    .build();
        } else {
            return Response
                    .status(Response.Status.OK)
                    .entity("Korisnik je uspješno dodan!")
                    .build();
        }
    }

    @Path("{korisnik}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dajKorisnika(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("korisnik") String pKorisnik) {
        
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Korisnik za ulazne podatke ne postoji !")
                    .build();
        }

        String idSjednice = dijeloviOdgovora[1];
        String komanda2 = "LIST " + korisnik + " " + idSjednice + " " + pKorisnik;
        String odgovor2 = posaljiKomanduNaPosluziteljKorisnika(komanda2);
        String[] dijeloviOdgovora2 = odgovor2.split(" ");
        
        if (dijeloviOdgovora2[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity(odgovor2)
                    .build();
        }
        
        String korisnikString = dijeloviOdgovora2[1];
        korisnikString = korisnikString.replace("\"", "");
        String korisnikStringDijelovi[] = korisnikString.split("\t");
        
        Korisnik k1 = new Korisnik(korisnikStringDijelovi[0], "******",
                    korisnikStringDijelovi[1], korisnikStringDijelovi[2]);
        return Response
                    .status(Response.Status.OK)
                    .entity(k1)
                    .build();
        
    }
    
    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int)context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String)context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();
                ) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }
            
            uticnica.shutdownInput();
            
            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspješno spajanje na serversku utičnicu !";
        }
    }

}
