package org.foi.nwtis.lpintaric.projekt.dretve;

import static java.lang.Thread.sleep;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.projekt.podaci.AirplanesDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.AirportDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.Meteo;
import org.foi.nwtis.lpintaric.projekt.podaci.MeteoDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportLog;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportsDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportsLogDAO;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Airport;
import org.foi.nwtis.rest.klijenti.OSKlijent;
import org.foi.nwtis.rest.klijenti.OWMKlijent;
import org.foi.nwtis.rest.podaci.AvionLeti;
import org.foi.nwtis.rest.podaci.MeteoOriginal;
import org.foi.nwtis.rest.podaci.MeteoPodaci;

public class PreuzimanjeMeteoPodataka extends Thread {

    private PostavkeBazaPodataka pbp;
    private OWMKlijent owmKlijent;
    private int trajanjeCiklusa;
    private boolean krajPreuzimanja;
    private String owmApiKey;

    List<String> oznakeOdabranihAerodroma = new ArrayList<>();
    List<MyAirportLog> logovi = null;
    AirportDAO airportDAO = null;
    MeteoDAO meteoDAO = null;
    MyAirportsDAO myAirportsDAO = new MyAirportsDAO();
    MyAirportsLogDAO myAirportsLogDAO = new MyAirportsLogDAO();
    AirplanesDAO airplanesDAO = new AirplanesDAO();

    public PreuzimanjeMeteoPodataka(PostavkeBazaPodataka pbp) {
        this.pbp = pbp;
        airportDAO = new AirportDAO();
        meteoDAO = new MeteoDAO();
    }

    @Override
    public void interrupt() {
        System.out.println("[PreuzimanjeMeteoPodataka]Zaustavljam dretvu!");
        this.krajPreuzimanja = true;
        super.interrupt();
    }

    @Override
    public void run() {
        System.out.println("[PreuzimanjeMeteoPodataka]Krećem s preuzimanjem podatka!");
        
        Meteo mZadnji = meteoDAO.dohvatiPosljednjiMeteo(pbp);
        long razlikaOdPosljednjegPreuzimanja = dohvatiTrenutnoVrijemeSekunde() - mZadnji.getVrijeme();
        if(razlikaOdPosljednjegPreuzimanja < (TimeUnit.MINUTES.toMillis(trajanjeCiklusa)/1000)){
            try {
                long cekaj = (TimeUnit.MINUTES.toMillis(trajanjeCiklusa)/1000) - razlikaOdPosljednjegPreuzimanja;
                sleep(cekaj * 1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(PreuzimanjeMeteoPodataka.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        while (!krajPreuzimanja) {
            System.out.println("[PreuzimanjeMeteoPodataka]Dohvacam trenutni meteo za aerodrome !");
            long pocetakObrade = System.currentTimeMillis();
            oznakeOdabranihAerodroma = myAirportsDAO.dohvatiOznakeSvihAerodroma(pbp);
            
            for (String ident : oznakeOdabranihAerodroma) {
                dohvatiMeteoZaAerodrom(ident);
            }
            
            long zavrsetakObrade = System.currentTimeMillis();
            long trajanjeObrade = zavrsetakObrade - pocetakObrade;
            
            try {
                sleep((trajanjeCiklusa * 60 * 1000) - trajanjeObrade);
            } catch (InterruptedException ex) {
                Logger.getLogger(PreuzimanjeLetovaAviona.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("[PreuzimanjeMeteoPodataka]Dretva zaustavljena!");
    }

    @Override
    public synchronized void start() {
        boolean status = Boolean.parseBoolean(pbp.dajPostavku("preuzimanje.status"));
        if (!status) {
            System.out.println("[PreuzimanjeMeteoPodataka]Ne preuzimamo nove podatke!");
        }
        this.trajanjeCiklusa = Integer.parseInt(pbp.dajPostavku("preuzimanjeMeteo.ciklus"));
        this.owmApiKey = pbp.dajPostavku("OpenWeatherMap.apikey");
        
        this.owmKlijent = new OWMKlijent(owmApiKey);

        super.start();
    }

    private void dohvatiMeteoZaAerodrom(String ident) {
        Aerodrom aerodrom = airportDAO.dohvatiAerodromPremaIcao(ident, pbp);
        MeteoOriginal mo = owmKlijent.getRealTimeWeatherOriginal(aerodrom.getLokacija().getLatitude(), aerodrom.getLokacija().getLongitude());
        float brzinaVjetra = 0;
        if(mo.getWindSpeed()!= null){
            brzinaVjetra = mo.getWindSpeed();
        }
        
        float smjerVjetra = 0;
        if(mo.getWindDeg()!= null){
            smjerVjetra = mo.getWindDeg();
        }

        Meteo m = new Meteo(ident, dohvatiTrenutnoVrijemeSekunde(), mo.getMainTemp(), "C", mo.getMainHumidity(),
                "%", mo.getMainPressure(), "Pa", brzinaVjetra, "km/h", smjerVjetra, "");
        meteoDAO.dodajMeteo(m, pbp);
    }

    private long pretvoriULong(String datum, String uzorak) {
        DateTimeFormatter dateFormatter
                = DateTimeFormatter.ofPattern(uzorak, Locale.ENGLISH);
        long milisekunde = LocalDate.parse(datum, dateFormatter)
                .atStartOfDay(ZoneOffset.UTC)
                .toInstant()
                .toEpochMilli();
        return milisekunde / 1000;
    }

    private long dohvatiDanasnjiDatum() {
        LocalDate date = LocalDate.now();
        return date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() / 1000;
    }
    
    private long dohvatiTrenutnoVrijemeSekunde(){
        return (System.currentTimeMillis() + TimeUnit.HOURS.toMillis(2)) / 1000;
    }

}
