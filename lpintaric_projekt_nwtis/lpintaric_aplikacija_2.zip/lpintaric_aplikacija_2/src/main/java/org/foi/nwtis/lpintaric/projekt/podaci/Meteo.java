package org.foi.nwtis.lpintaric.projekt.podaci;

import java.io.Serializable;

public class Meteo implements Serializable{
    private String icao;
    private long vrijeme;
    private float temperatura;
    private String temperatura_jedinica;
    private float vlaga;
    private String vlaga_jedinica;
    private float tlak;
    private String tlak_jedinica;
    private float brzina_vjetra;
    private String brzina_vjetra_naziv;
    private float smjer_vjetra;
    private String smjer_vjetra_naziv;

    public Meteo(String icao, long vrijeme, float temperatura, String temperatura_jedinica, float vlaga, String vlaga_jedinica, float tlak, String tlak_jedinica, float brzina_vjetra, String brzina_vjetra_naziv, float smjer_kretanja, String smjer_vjetra_naziv) {
        this.icao = icao;
        this.vrijeme = vrijeme;
        this.temperatura = temperatura;
        this.temperatura_jedinica = temperatura_jedinica;
        this.vlaga = vlaga;
        this.vlaga_jedinica = vlaga_jedinica;
        this.tlak = tlak;
        this.tlak_jedinica = tlak_jedinica;
        this.brzina_vjetra = brzina_vjetra;
        this.brzina_vjetra_naziv = brzina_vjetra_naziv;
        this.smjer_vjetra = smjer_kretanja;
        this.smjer_vjetra_naziv = smjer_vjetra_naziv;
    }

    public String getIcao() {
        return icao;
    }

    public void setIcao(String icao) {
        this.icao = icao;
    }

    public long getVrijeme() {
        return vrijeme;
    }

    public void setVrijeme(long vrijeme) {
        this.vrijeme = vrijeme;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    public String getTemperatura_jedinica() {
        return temperatura_jedinica;
    }

    public void setTemperatura_jedinica(String temperatura_jedinica) {
        this.temperatura_jedinica = temperatura_jedinica;
    }

    public float getVlaga() {
        return vlaga;
    }

    public void setVlaga(float vlaga) {
        this.vlaga = vlaga;
    }

    public String getVlaga_jedinica() {
        return vlaga_jedinica;
    }

    public void setVlaga_jedinica(String vlaga_jedinica) {
        this.vlaga_jedinica = vlaga_jedinica;
    }

    public float getTlak() {
        return tlak;
    }

    public void setTlak(float tlak) {
        this.tlak = tlak;
    }

    public String getTlak_jedinica() {
        return tlak_jedinica;
    }

    public void setTlak_jedinica(String tlak_jedinica) {
        this.tlak_jedinica = tlak_jedinica;
    }

    public float getBrzina_vjetra() {
        return brzina_vjetra;
    }

    public void setBrzina_vjetra(float brzina_vjetra) {
        this.brzina_vjetra = brzina_vjetra;
    }

    public String getBrzina_vjetra_naziv() {
        return brzina_vjetra_naziv;
    }

    public void setBrzina_vjetra_naziv(String brzina_vjetra_naziv) {
        this.brzina_vjetra_naziv = brzina_vjetra_naziv;
    }

    public float getSmjer_vjetra() {
        return smjer_vjetra;
    }

    public void setSmjer_vjetra(float smjer_vjetra) {
        this.smjer_vjetra = smjer_vjetra;
    }

    public String getSmjer_vjetra_naziv() {
        return smjer_vjetra_naziv;
    }

    public void setSmjer_vjetra_naziv(String smjer_vjetra_naziv) {
        this.smjer_vjetra_naziv = smjer_vjetra_naziv;
    }

    
    
}
