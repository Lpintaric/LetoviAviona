package org.foi.nwtis.lpintaric.projekt.rest;

import com.mysql.cj.Query;
import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.projekt.podaci.AirportDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirport;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportsDAO;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Airport;
import org.foi.nwtis.rest.podaci.AvionLeti;

@Path("mojiAerodromi")
public class MojiAerodromiResource {

    @Inject
    ServletContext context;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiSvePraceneAerodrome(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }

        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        AirportDAO adao = new AirportDAO();
        List<Aerodrom> aerodromi = adao.dohvatiSvePraceneAerodrome(pbp);
        return Response
                .status(Response.Status.OK)
                .entity(aerodromi)
                .build();
    }

    @Path("{icao}/prate")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiKorisnikeKojiPrateAerodrom(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("icao") String icao) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }

        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        MyAirportsDAO madao = new MyAirportsDAO();
        List<MyAirport> pracenja = madao.dohvatiPracenjaAerodroma(icao, pbp);

        List<Korisnik> korisnici = new ArrayList<>();
        for (MyAirport p : pracenja) {
            String idSjednice = dijeloviOdgovora[1];
            String komanda2 = "LIST " + korisnik + " " + idSjednice + " " + p.getUsername();
            String odgovor2 = posaljiKomanduNaPosluziteljKorisnika(komanda2);
            String[] dijeloviOdgovora2 = odgovor2.split(" ");

            String korisnikString = dijeloviOdgovora2[1];
            korisnikString = korisnikString.replace("\"", "");
            String korisnikStringDijelovi[] = korisnikString.split("\t");

            Korisnik k1 = new Korisnik(korisnikStringDijelovi[0], "******",
                    korisnikStringDijelovi[1], korisnikStringDijelovi[2]);
            
            korisnici.add(k1);
        }

        return Response
                .status(Response.Status.OK)
                .entity(korisnici)
                .build();
    }

    @Path("{korisnik}/prati")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiAerodromeKojePratiKorisnik(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("korisnik") String korisnik2) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }

        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        MyAirportsDAO madao = new MyAirportsDAO();
        List<Aerodrom> aerodromi = madao.dohvatiAerodromeKojePratiKorisnik(korisnik2, pbp);
        return Response
                .status(Response.Status.OK)
                .entity(aerodromi)
                .build();
    }

    @Path("{korisnik}/prati")
    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response dodajAerodromUListuPracenih(Aerodrom aerodrom,
            @HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("korisnik") String pkorisnik) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }

        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        MyAirportsDAO madao = new MyAirportsDAO();
        boolean uspjesno = madao.dodajAerodromUListuPracenih(pkorisnik, aerodrom, pbp);
        if (!uspjesno) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Nije moguće dodati aerodrom!")
                    .build();
        } else {
            return Response
                    .status(Response.Status.OK)
                    .entity("Aerodrom uspješno dodan !")
                    .build();
        }
    }

    @Path("{korisnik}/prati/{icao}")
    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    public Response obrisiAerodromIzListePracenih(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("korisnik") String korisnik2,
            @PathParam("icao") String icao) {
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Neuspjela autentikacija, pogrešni podaci za korisnika !")
                    .build();
        }

        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        MyAirportsDAO madao = new MyAirportsDAO();
        boolean uspjesno = madao.obrisiAerodromIzListePracenih(korisnik2, icao, pbp);
        if (!uspjesno) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Aerodrom za dani icao nije zapracen!")
                    .build();
        } else {
            return Response
                    .status(Response.Status.OK)
                    .entity("Aerodrom uspješno obrisan iz liste !")
                    .build();
        }
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspješno spajanje na serversku utičnicu !";
        }
    }

}
