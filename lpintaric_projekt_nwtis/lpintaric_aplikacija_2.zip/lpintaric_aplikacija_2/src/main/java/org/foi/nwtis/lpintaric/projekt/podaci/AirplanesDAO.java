package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Airport;
import org.foi.nwtis.podaci.Korisnik;
import org.foi.nwtis.podaci.MyAirport;
import org.foi.nwtis.rest.podaci.AvionLeti;

public class AirplanesDAO {

    public boolean dodajLet(AvionLeti al, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "INSERT INTO airplanes (icao24, firstSeen, estDepartureAirport, lastSeen, estArrivalAirport, callsign,"
                + "estDepartureAirportHorizDistance, estDepartureAirportVertDistance, estArrivalAirportHorizDistance, estArrivalAirportVertDistance, "
                + "departureAirportCandidatesCount, arrivalAirportCandidatesCount, stored) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, al.getIcao24());
                s.setInt(2, al.getFirstSeen());
                s.setString(3, al.getEstDepartureAirport());
                s.setInt(4, al.getLastSeen());
                s.setString(5, al.getEstArrivalAirport());
                s.setString(6, al.getCallsign());
                s.setInt(7, al.getEstDepartureAirportHorizDistance());
                s.setInt(8, al.getEstDepartureAirportVertDistance());
                s.setInt(9, al.getEstArrivalAirportHorizDistance());
                s.setInt(10, al.getEstArrivalAirportVertDistance());
                s.setInt(11, al.getDepartureAirportCandidatesCount());
                s.setInt(12, al.getArrivalAirportCandidatesCount());

                int brojAzuriranja = s.executeUpdate();

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public List<AvionLeti> dohvatiLetoveZaAerodrom(String icao, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * FROM AIRPLANES WHERE ESTDEPARTUREAIRPORT = ?";

        try {
            Class.forName(pbp.getDriverDatabase(url));
            List<AvionLeti> letovi = new ArrayList<>();
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, icao);

                ResultSet rs = s.executeQuery();

                while (rs.next()) {
                    String icao24 = rs.getString("icao24");
                    int firstSeen = rs.getInt("firstSeen");
                    String estDepartureAirport = rs.getString("estDepartureAirport");
                    int lastSeen = rs.getInt("lastSeen");
                    String estArrivalAirport = rs.getString("estArrivalAirport");
                    String callsign = rs.getString("callsign");
                    int estDepartureAirportHorizDistance = rs.getInt("estDepartureAirportHorizDistance");
                    int estDepartureAirportVertDistance = rs.getInt("estDepartureAirportVertDistance");
                    int estArrivalAirportHorizDistance = rs.getInt("estArrivalAirportHorizDistance");
                    int estArrivalAirportVertDistance = rs.getInt("estArrivalAirportVertDistance");
                    int departureAirportCandidatesCount = rs.getInt("departureAirportCandidatesCount");
                    int arrivalAirportCandidatesCount = rs.getInt("arrivalAirportCandidatesCount");

                    AvionLeti al = new AvionLeti(icao24, firstSeen, estDepartureAirport, lastSeen, estArrivalAirport, 
                            callsign, estDepartureAirportHorizDistance, estDepartureAirportVertDistance, estArrivalAirportHorizDistance, 
                            estArrivalAirportVertDistance, departureAirportCandidatesCount, arrivalAirportCandidatesCount);
                    letovi.add(al);
                    
                }
                return letovi;
            } catch (SQLException ex) {
                Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public int dohvatiBrojLetovaZaAerodrom(String icao, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT COUNT(*) AS BROJ_LETOVA FROM AIRPLANES WHERE ESTDEPARTUREAIRPORT = ?";

        try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, icao);

                ResultSet rs = s.executeQuery();

                while (rs.next()) {
                    int brojLetova = rs.getInt("broj_letova");
                    return brojLetova;
                    
                }
                
            } catch (SQLException ex) {
                Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public List<AvionLeti> dohvatiLetoveAerodromaZaDan(String icao, long dan, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        long pocetnoVrijeme = dan;
        long zavrsnoVrijeme = dan + TimeUnit.DAYS.toMillis(1)/1000;
        String upit = "SELECT * FROM AIRPLANES WHERE"
                + " ESTDEPARTUREAIRPORT = '" + icao + "'"
                + " AND FIRSTSEEN > " + pocetnoVrijeme
                + " AND FIRSTSEEN < " + zavrsnoVrijeme;

        try {
            Class.forName(pbp.getDriverDatabase(url));
            List<AvionLeti> letovi = new ArrayList<>();
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    String icao24 = rs.getString("icao24");
                    int firstSeen = rs.getInt("firstSeen");
                    String estDepartureAirport = rs.getString("estDepartureAirport");
                    int lastSeen = rs.getInt("lastSeen");
                    String estArrivalAirport = rs.getString("estArrivalAirport");
                    String callsign = rs.getString("callsign");
                    int estDepartureAirportHorizDistance = rs.getInt("estDepartureAirportHorizDistance");
                    int estDepartureAirportVertDistance = rs.getInt("estDepartureAirportVertDistance");
                    int estArrivalAirportHorizDistance = rs.getInt("estArrivalAirportHorizDistance");
                    int estArrivalAirportVertDistance = rs.getInt("estArrivalAirportVertDistance");
                    int departureAirportCandidatesCount = rs.getInt("departureAirportCandidatesCount");
                    int arrivalAirportCandidatesCount = rs.getInt("arrivalAirportCandidatesCount");

                    AvionLeti al = new AvionLeti(icao24, firstSeen, estDepartureAirport, lastSeen, estArrivalAirport, 
                            callsign, estDepartureAirportHorizDistance, estDepartureAirportVertDistance, estArrivalAirportHorizDistance, 
                            estArrivalAirportVertDistance, departureAirportCandidatesCount, arrivalAirportCandidatesCount);
                    letovi.add(al);
                    
                }
                return letovi;
            } catch (SQLException ex) {
                Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
