package org.foi.nwtis.lpintaric.projekt.slusaci;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.projekt.dretve.PreuzimanjeLetovaAviona;
import org.foi.nwtis.lpintaric.projekt.dretve.PreuzimanjeMeteoPodataka;
import org.foi.nwtis.lpintaric.vjezba_03.konfiguracije.NeispravnaKonfiguracija;

@WebListener
public class SlusacAplikacije implements ServletContextListener {

    private PreuzimanjeLetovaAviona pla;
    private PreuzimanjeMeteoPodataka pma;
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if(pla != null && pla.isAlive())
            pla.interrupt();
        
        if(pma != null && pma.isAlive())
            pma.interrupt();
        
        ServletContext servletContext = sce.getServletContext();
        servletContext.removeAttribute("Postavke");
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext servletContext = sce.getServletContext();
        
        String putanjaKonfDatoteke = servletContext.getRealPath("WEB-INF")+File.separator+servletContext.getInitParameter("konfiguracija");
        PostavkeBazaPodataka pbp = new PostavkeBazaPodataka(putanjaKonfDatoteke);
        
        try {
            pbp.ucitajKonfiguraciju();
            servletContext.setAttribute("Postavke", pbp);
            
            dohvatiPostavke(pbp, servletContext);
            
            pla = new PreuzimanjeLetovaAviona(pbp);
            pla.start();
            pma = new PreuzimanjeMeteoPodataka(pbp);
            pma.start();

        } catch (NeispravnaKonfiguracija ex) {
            Logger.getLogger(SlusacAplikacije.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void dohvatiPostavke(PostavkeBazaPodataka pbp, ServletContext servletContext) {
        int posluziteljKorisniciPort = Integer.parseInt(pbp.dajPostavku("posluziteljKorisnici.port"));
        servletContext.setAttribute("posluziteljKorisniciPort", posluziteljKorisniciPort);
        String posluziteljKorisniciAdresa = pbp.dajPostavku("posluziteljKorisnici.adresa");
        servletContext.setAttribute("posluziteljKorisniciAdresa", posluziteljKorisniciAdresa);
    }
    
}
