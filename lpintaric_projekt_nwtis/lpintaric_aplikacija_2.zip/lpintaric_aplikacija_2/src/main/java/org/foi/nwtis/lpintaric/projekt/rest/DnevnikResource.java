package org.foi.nwtis.lpintaric.projekt.rest;

import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.lpintaric.projekt.podaci.Dnevnik;
import org.foi.nwtis.lpintaric.projekt.podaci.DnevnikDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;

@Path("dnevnik")
public class DnevnikResource {

    @Inject
    ServletContext context;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response dodajZapisUDnvenik(Dnevnik d) {
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        DnevnikDAO ddao = new DnevnikDAO();
        boolean uspjesnoDodano = ddao.dodajZapis(d, pbp);
        if (!uspjesnoDodano) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Zapis nije moguće dodati u dnevnik !")
                    .build();
        } else {
            return Response
                    .status(Response.Status.OK)
                    .entity("Zapis je uspješno dodan u dnevnik!")
                    .build();
        }
    }

    @Path("{korisnik}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiZapiseZaKorisnika(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("korisnik") String pKorisnik,
            @QueryParam("odVremena") String odVremena,
            @QueryParam("doVremena") String doVremena,
            @QueryParam("pomak") String pomak,
            @QueryParam("stranica") String stranica
            ) {
        
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Korisnik za ulazne podatke ne postoji !")
                    .build();
        }
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        DnevnikDAO ddao = new DnevnikDAO();
        boolean interval = false;
        boolean stranicenje = false;
        long odVremenaLong = 0;
        long doVremenaLong = 0;
        int pomakInt = 0;
        int stranicaInt = 0;
        System.out.println(odVremena);
        if(!odVremena.equals("") && !doVremena.equals("")){
            interval = true;
            odVremenaLong = Long.parseLong(odVremena);
            doVremenaLong = Long.parseLong(doVremena);
            
        }
        if(!pomak.equals("") && !stranica.equals("")){
            stranicenje = true;
            pomakInt = Integer.parseInt(pomak);
            stranicaInt = Integer.parseInt(stranica);
        }
        List<Dnevnik> zapisiDnevnika = ddao.dohvatiZapiseZaKorisnika(pKorisnik, odVremenaLong, doVremenaLong,
                pomakInt, stranicaInt, interval, stranicenje, pbp);
        
        return Response
                    .status(Response.Status.OK)
                    .entity(zapisiDnevnika)
                    .build();
        
    }
    
    @Path("{korisnik}/broj")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response dohvatiBrojZapisaZaKorisnika(@HeaderParam("korisnik") String korisnik,
            @HeaderParam("lozinka") String lozinka,
            @PathParam("korisnik") String pKorisnik,
            @QueryParam("odVremena") String odVremena,
            @QueryParam("doVremena") String doVremena
            ) {
        
        String komanda = "AUTHEN " + korisnik + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        if (dijeloviOdgovora[0].equals("ERROR")) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Korisnik za ulazne podatke ne postoji !")
                    .build();
        }
        
        PostavkeBazaPodataka pbp = (PostavkeBazaPodataka) context.getAttribute("Postavke");
        DnevnikDAO ddao = new DnevnikDAO();
        boolean interval = false;
        long odVremenaLong = 0;
        long doVremenaLong = 0;
        
        if(!odVremena.equals("") && !doVremena.equals("")){
            interval = true;
            odVremenaLong = Long.parseLong(odVremena);
            doVremenaLong = Long.parseLong(doVremena);
            
        }
        int brojZapisa = ddao.dohvatiBrojZapisaZaKorisnika(pKorisnik, odVremenaLong, doVremenaLong, interval, pbp);
        
        return Response
                    .status(Response.Status.OK)
                    .entity(brojZapisa)
                    .build();
        
    }
    
    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int)context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String)context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();
                ) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }
            
            uticnica.shutdownInput();
            
            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspješno spajanje na serversku utičnicu !";
        }
    }

}
