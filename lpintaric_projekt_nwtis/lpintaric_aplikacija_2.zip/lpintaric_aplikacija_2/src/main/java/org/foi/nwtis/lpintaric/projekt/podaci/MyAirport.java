package org.foi.nwtis.lpintaric.projekt.podaci;

import java.io.Serializable;
import java.sql.Timestamp;

public class MyAirport implements Serializable {
    private int id;
    private String ident;
    private String username;
    private Timestamp stored;

    public MyAirport() {
    }
    
    public MyAirport(int id, String ident, String username, Timestamp stored) {
        this.id = id;
        this.ident = ident;
        this.username = username;
        this.stored = stored;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIdent() {
        return ident;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Timestamp getStored() {
        return stored;
    }

    public void setStored(Timestamp stored) {
        this.stored = stored;
    }
    
    
    
    
}
