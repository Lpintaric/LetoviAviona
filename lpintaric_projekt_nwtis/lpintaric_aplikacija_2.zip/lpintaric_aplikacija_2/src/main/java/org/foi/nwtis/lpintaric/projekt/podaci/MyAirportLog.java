package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Timestamp;
import java.util.Date;

public class MyAirportLog {
    private String ident;
    private Date flightDate;
    private Timestamp stored;

    public MyAirportLog() {
    }

    public MyAirportLog(String ident, Date flightDate, Timestamp stored) {
        this.ident = ident;
        this.flightDate = flightDate;
        this.stored = stored;
    }

    public String getIdent() {
        return ident;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public Date getFlightDate() {
        return flightDate;
    }

    public void setFlightDate(Date flightDate) {
        this.flightDate = flightDate;
    }

    public Timestamp getStored() {
        return stored;
    }

    public void setStored(Timestamp stored) {
        this.stored = stored;
    }

    @Override
    public String toString() {
        return "MyAirportLog{" + "ident=" + ident + ", flightDate=" + flightDate + ", stored=" + stored + '}';
    }
    
    
    
    
    
}
