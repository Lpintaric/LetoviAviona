package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.rest.podaci.AvionLeti;
import org.foi.nwtis.rest.podaci.Lokacija;

public class DnevnikDAO {

    public boolean dodajZapis(Dnevnik d, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "INSERT INTO dnevnik (korisnik ,vrijeme_primitka_komande, sadrzaj_komande, status_odgovora) "
                + "VALUES ('" + d.getKorisnik() + "', " + d.getVrijemePrimitkaKomande() + ", '" + d.getSadrzajKomande() 
                + "', '" + d.getStatusOdgvovora() + "')";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {


                int brojAzuriranja = s.executeUpdate(upit);

                return brojAzuriranja == 1;

            } catch (SQLException ex) {
                Logger.getLogger(DnevnikDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DnevnikDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public List<Dnevnik> dohvatiZapiseZaKorisnika(String korisnik, long odVremena, long doVremena, 
            int pomak, int stranica, boolean interval, boolean stranicenje, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * FROM dnevnik WHERE korisnik = '" + korisnik + "'";
        
        if(interval){
            upit += " AND vrijeme_primitka_komande >= " + odVremena 
                    + " AND vrijeme_primitka_komande <= " + doVremena; 
        }
        if (stranicenje){
            upit += " LIMIT " + pomak + "," + stranica;
        }
        
        System.out.println("Upit :" + upit);
            
        try {
            Class.forName(pbp.getDriverDatabase(url));
            List<Dnevnik> zapisiDnevnika = new ArrayList<>();
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    String korisnik1 = rs.getString("korisnik");
                    long vrijeme_primitka_komande = rs.getLong("vrijeme_primitka_komande");
                    String sadrzaj_komande = rs.getString("sadrzaj_komande");
                    String status_odgovora = rs.getString("status_odgovora");

                    Dnevnik d = new Dnevnik(korisnik1, vrijeme_primitka_komande, sadrzaj_komande, status_odgovora);
                    zapisiDnevnika.add(d);
                }
                return zapisiDnevnika;
            } catch (SQLException ex) {
                Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public int dohvatiBrojZapisaZaKorisnika(String korisnik, long odVremena, long doVremena, 
            boolean interval, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT COUNT(*) AS broj_zapisa FROM dnevnik WHERE korisnik = '" + korisnik + "'";
        
        if(interval){
            upit += " AND vrijeme_primitka_komande >= " + odVremena 
                    + " AND vrijeme_primitka_komande <= " + doVremena; 
        }
            
        try {
            Class.forName(pbp.getDriverDatabase(url));
            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    int broj_zapisa = rs.getInt("broj_zapisa");
                    return broj_zapisa;
                }
            } catch (SQLException ex) {
                Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirplanesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}

