package org.foi.nwtis.lpintaric.projekt.rest;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@ApplicationPath("rest")
public class JakartaRestConfiguration extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> klase = new HashSet<>();
        klase.add(KorisniciResource.class);
        klase.add(AerodromiResource.class);
        klase.add(MojiAerodromiResource.class);
        klase.add(DnevnikResource.class);
        return klase;
    }
}
