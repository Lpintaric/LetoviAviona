package org.foi.nwtis.lpintaric.projekt.dretve;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.rest.klijenti.OSKlijent;
import org.foi.nwtis.rest.podaci.AvionLeti;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import org.foi.nwtis.lpintaric.projekt.podaci.AirplanesDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportLog;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportsDAO;
import org.foi.nwtis.lpintaric.projekt.podaci.MyAirportsLogDAO;

public class PreuzimanjeLetovaAviona extends Thread {

    private PostavkeBazaPodataka pbp;
    private OSKlijent osKlijent;
    private int trajanjeCiklusa;
    private int trajanjePauze;
    private long pocetniDatum;
    private long krajnjiDatum;
    private String osKorime;
    private String osLozinka;
    private boolean krajPreuzimanja;

    List<String> oznakeOdabranihAerodroma = new ArrayList<>();
    List<MyAirportLog> logovi = null;
    MyAirportsDAO myAirportsDAO = new MyAirportsDAO();
    MyAirportsLogDAO myAirportsLogDAO = new MyAirportsLogDAO();
    AirplanesDAO airplanesDAO = new AirplanesDAO();

    public PreuzimanjeLetovaAviona(PostavkeBazaPodataka pbp) {
        this.pbp = pbp;
    }

    @Override
    public void interrupt() {
        System.out.println("[PreuzimanjeLetova]Zaustavljam dretvu!");
        this.krajPreuzimanja = true;
        super.interrupt();
    }

    @Override
    public void run() {
        Long trenutniDatum = this.pocetniDatum;
        boolean izvrsenoPreuzimanje;

        System.out.println("[PreuzimanjeLetova]Krećemo s preuzimanjem podatka!");
        while (!krajPreuzimanja) {
            long pocetakObrade = System.currentTimeMillis();

            if (trenutniDatum > krajnjiDatum) {
                break;
            }
            if (trenutniDatum >= dohvatiDanasnjiDatum()) {
                try {
                    System.out.println("[PreuzimanjeLetova]Pauziram jedan dan !");
                    sleep(TimeUnit.DAYS.toMillis(1));
                } catch (InterruptedException ex) {
                    Logger.getLogger(PreuzimanjeLetovaAviona.class.getName()).log(Level.SEVERE, null, ex);
                }
                continue;
            }
            
            oznakeOdabranihAerodroma = myAirportsDAO.dohvatiOznakeSvihAerodroma(pbp);
            izvrsenoPreuzimanje = false;
            for (String ident : oznakeOdabranihAerodroma) {
                izvrsenoPreuzimanje = dohvatiLetoveZaAerodrom(ident, trenutniDatum);

                if (izvrsenoPreuzimanje) {
                    try {
                        sleep(trajanjePauze);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(PreuzimanjeLetovaAviona.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            trenutniDatum += TimeUnit.DAYS.toMillis(1) / 1000;

            if (izvrsenoPreuzimanje) {
                System.out.println("[PreuzimanjeLetova]Preuzeo sam podatke!");
                long zavrsetakObrade = System.currentTimeMillis();
                long trajanjeObrade = zavrsetakObrade - pocetakObrade;
                long vrijemeCekanja = trajanjeCiklusa * 1000 - trajanjeObrade;
                if (vrijemeCekanja > 0) {
                    try {
                        sleep(vrijemeCekanja);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(PreuzimanjeLetovaAviona.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            } else {
                System.out.println("[PreuzimanjeLetova]Za trenutni dan su podaci već preuzeti!");
            }
        }
        System.out.println("[PreuzimanjeLetova]Dretva zaustavljena!");
    }

    @Override
    public synchronized void start() {
        boolean status = Boolean.parseBoolean(pbp.dajPostavku("preuzimanje.status"));
        if (!status) {
            System.out.println("Ne preuzimamo nove podatke!");
            return;
        }
        this.trajanjeCiklusa = Integer.parseInt(pbp.dajPostavku("preuzimanje.ciklus"));
        this.trajanjePauze = Integer.parseInt(pbp.dajPostavku("preuzimanje.pauza"));
        this.pocetniDatum = pretvoriULong(pbp.dajPostavku("preuzimanje.pocetak"), "dd.MM.yyyy");
        this.krajnjiDatum = pretvoriULong(pbp.dajPostavku("preuzimanje.kraj"), "dd.MM.yyyy");
        this.osKorime = pbp.dajPostavku("OpenSkyNetwork.korisnik");
        this.osLozinka = pbp.dajPostavku("OpenSkyNetwork.lozinka");
        this.osKlijent = new OSKlijent(osKorime, osLozinka);

        super.start();
    }

    private boolean dohvatiLetoveZaAerodrom(String ident, long trenutniDatum) {
        logovi = myAirportsLogDAO.getAllLogs(pbp);

        boolean nePostojiLog = true;
        for (MyAirportLog log : logovi) {
            long datumLog = pretvoriULong(log.getFlightDate().toString(), "yyyy-MM-dd");
            if (log.getIdent().equals(ident) && datumLog == trenutniDatum) {
                nePostojiLog = false;
                break;
            }
        }
        
        if (nePostojiLog) {
            List<AvionLeti> letovi = osKlijent.getDepartures(ident, trenutniDatum, trenutniDatum + TimeUnit.DAYS.toMillis(1) / 1000);
            for (AvionLeti let : letovi) {
                if (let.getEstArrivalAirport() != null) {
                    airplanesDAO.dodajLet(let, pbp);
                }
            }
            Date d = new Date(TimeUnit.SECONDS.toMillis(trenutniDatum));
            MyAirportLog noviLog = new MyAirportLog(ident, d, null);
            myAirportsLogDAO.addLog(noviLog, pbp);
            return true;
        }
        return false;
    }

    private long pretvoriULong(String datum, String uzorak) {
        DateTimeFormatter dateFormatter
                = DateTimeFormatter.ofPattern(uzorak, Locale.ENGLISH);
        long milisekunde = LocalDate.parse(datum, dateFormatter)
                .atStartOfDay(ZoneOffset.UTC)
                .toInstant()
                .toEpochMilli();
        return milisekunde / 1000;
    }

    private long dohvatiDanasnjiDatum() {
        LocalDate date = LocalDate.now();
        return date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() / 1000;
    }

}
