package org.foi.nwtis.lpintaric.projekt.podaci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Airport;

import org.foi.nwtis.podaci.Korisnik;
import org.foi.nwtis.rest.podaci.Lokacija;

public class AirportDAO {

    public List<Aerodrom> dohvatiSveAerodrome(String naziv, String drzava, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * FROM AIRPORTS";
        if (!naziv.equals("")) {
            upit += " WHERE `name` LIKE '" + naziv + "'";
            if (!drzava.equals("")) {
                upit += " AND ISO_COUNTRY = '" + drzava + "'";
            }
        } else if (!drzava.equals("")) {
            upit += " WHERE ISO_COUNTRY = '" + drzava + "'";
        }
        
        System.out.println("Upit : '" + upit + "'");

        try {
            Class.forName(pbp.getDriverDatabase(url));

            List<Aerodrom> aerodromi = new ArrayList<>();

            try (
                    Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                    Statement s = con.createStatement()) {

                
                ResultSet rs = s.executeQuery(upit);

                while (rs.next()) {
                    String ident = rs.getString("ident");
                    String name = rs.getString("name");
                    String iso_country = rs.getString("iso_country");
                    String coordinates = rs.getString("coordinates");
                    coordinates = coordinates.replaceAll("\\s", "");
                    String[] razdvojeneKoordinate = coordinates.split(",");
                    Lokacija lokacija = new Lokacija(razdvojeneKoordinate[1], razdvojeneKoordinate[0]);

                    Aerodrom a = new Aerodrom(ident, name, iso_country, lokacija);

                    aerodromi.add(a);
                }
                return aerodromi;

            } catch (SQLException ex) {
                Logger.getLogger(AirportDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirportDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
     public Aerodrom dohvatiAerodromPremaIcao(String icao, PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT * "
                + "FROM airports WHERE ident = ?";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                     PreparedStatement s = con.prepareStatement(upit)) {

                s.setString(1, icao);

                ResultSet rs = s.executeQuery();

                while (rs.next()) {
                    String ident = rs.getString("ident");
                    String name = rs.getString("name");
                    String iso_country = rs.getString("iso_country");
                    String coordinates = rs.getString("coordinates");
                    coordinates = coordinates.replaceAll("\\s", "");
                    String[] razdvojeneKoordinate = coordinates.split(",");
                    Lokacija lokacija = new Lokacija(razdvojeneKoordinate[1], razdvojeneKoordinate[0]);

                    Aerodrom a = new Aerodrom(ident, name, iso_country, lokacija);
                    return a;
                }

            } catch (SQLException ex) {
                Logger.getLogger(AirportDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirportDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
     
    public List<Aerodrom> dohvatiSvePraceneAerodrome(PostavkeBazaPodataka pbp) {
        String url = pbp.getServerDatabase() + pbp.getUserDatabase();
        String bpkorisnik = pbp.getUserUsername();
        String bplozinka = pbp.getUserPassword();
        String upit = "SELECT DISTINCT A.IDENT, A.NAME, A.ISO_COUNTRY, A.COORDINATES FROM AIRPORTS A "
                + "RIGHT JOIN MYAIRPORTS MA ON A.IDENT = MA.IDENT";

        try {
            Class.forName(pbp.getDriverDatabase(url));

            List<Aerodrom> aerodromi = new ArrayList<>();

            try (
                     Connection con = DriverManager.getConnection(url, bpkorisnik, bplozinka);
                     Statement s = con.createStatement();
                     ResultSet rs = s.executeQuery(upit)) {

                while (rs.next()) {
                    String icao = rs.getString("IDENT");
                    String naziv = rs.getString("NAME");
                    String drzava = rs.getString("ISO_COUNTRY");
                    String koordinate = rs.getString("COORDINATES");
                    koordinate = koordinate.replaceAll("\\s", "");
                    String[] razdvojeneKoordinate = koordinate.split(",");
                    Lokacija lokacija = new Lokacija(razdvojeneKoordinate[1], razdvojeneKoordinate[0]);
                    
                    Aerodrom a = new Aerodrom(icao, naziv, drzava, lokacija);

                    aerodromi.add(a);
                }
                return aerodromi;

            } catch (SQLException ex) {
                Logger.getLogger(AirportDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AirportDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}

