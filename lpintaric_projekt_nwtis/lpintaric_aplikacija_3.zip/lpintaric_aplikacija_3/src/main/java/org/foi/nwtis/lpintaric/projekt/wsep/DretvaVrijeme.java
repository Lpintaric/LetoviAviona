/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.lpintaric.projekt.wsep;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.lpintaric.konfiguracije.bazaPodataka.PostavkeBazaPodataka;

/**
 *
 * @author lukap
 */
public class DretvaVrijeme extends Thread {

    private boolean radi;
    private int interval;
    private PostavkeBazaPodataka pbp;
    
    public DretvaVrijeme(PostavkeBazaPodataka pbp) {
        this.pbp = pbp;
    }

    @Override
    public synchronized void start() {
        radi = true;
        interval = Integer.parseInt(pbp.dajPostavku("slanjeVremena.interval"));
        super.start();
    }

    @Override
    public void run() {
        while (radi) {
            long pocetakObrade = System.currentTimeMillis();
            
            String vrijeme = dohvatiVrijeme();
            KTVrijeme.sendAll(vrijeme);
            System.out.println("Vrijeme poslano");
            
            long zavrsetakObrade = System.currentTimeMillis();
            long trajanjeObrade = zavrsetakObrade - pocetakObrade;
            long vrijemeCekanja = interval * 1000 - trajanjeObrade;
            try {
                sleep(vrijemeCekanja);
            } catch (InterruptedException ex) {
                Logger.getLogger(DretvaVrijeme.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void interrupt() {
        radi = false;
    }

    private String dohvatiVrijeme() {
        SimpleDateFormat formater = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        Date trenutnoVrijeme = new Date();
        String vrijemeZahtjeva = formater.format(trenutnoVrijeme);
        return vrijemeZahtjeva;
    }

}
