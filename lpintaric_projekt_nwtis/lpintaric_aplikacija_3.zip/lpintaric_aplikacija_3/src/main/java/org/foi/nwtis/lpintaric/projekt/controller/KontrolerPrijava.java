package org.foi.nwtis.lpintaric.projekt.controller;

import com.sun.net.httpserver.HttpContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Application;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.wsep.OglasnikPrijava;
import org.foi.nwtis.podaci.Korisnik;

@Path("korisnikPrijava")
@Controller
public class KontrolerPrijava {

    @Inject
    ServletContext context;

    @Inject
    HttpServletRequest request;

    @Inject
    Models model;

    @FormParam("korime")
    String korime;

    @FormParam("lozinka")
    String lozinka;
    
    @Inject
    OglasnikPrijava oglasnikPrijava;

    @POST
    public String prijavaKorisnika() {
        String komanda = "AUTHEN " + korime + " " + lozinka;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            HttpSession sesija = request.getSession(false);
            int idSjednice = Integer.parseInt(dijeloviOdgovora[1]);
            sesija.setAttribute("idSjednice", idSjednice);
            sesija.setAttribute("korime", korime);
            sesija.setAttribute("lozinka", lozinka);
            
            String poruka = "PRIJAVA;" + korime + ";lpintaric_aplikacija_3;" + dohvatiVrijeme();
            oglasnikPrijava.posaljiPoruku(poruka);
            
            return "izbornik.jsp";
        }

        if (dijeloviOdgovora[0].equals("ERROR")) {
            model.put("greska", "Pogresni podaci za prijavu!");
            return "greska.jsp";
        }

        // spoji se na '/login' krajnju to�ku i po�alji korisni�ke podatke
        return "";
    }
    
    private String dohvatiVrijeme() {
        SimpleDateFormat formater = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        Date trenutnoVrijeme = new Date();
        String vrijemeZahtjeva = formater.format(trenutnoVrijeme);
        return vrijemeZahtjeva;
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspje�no spajanje na serversku uti�nicu !";
        }
    }
}
