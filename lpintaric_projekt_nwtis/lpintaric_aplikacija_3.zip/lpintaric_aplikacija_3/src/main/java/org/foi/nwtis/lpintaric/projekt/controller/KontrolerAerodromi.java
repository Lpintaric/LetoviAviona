package org.foi.nwtis.lpintaric.projekt.controller;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Application;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_2;
import org.foi.nwtis.lpintaric.projekt.podaci.KorisniciKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_2;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_3;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_4;
import org.foi.nwtis.podaci.Aerodrom;

@Path("aerodromi")
@Controller
public class KontrolerAerodromi {

    @Inject
    ServletContext context;

    @Inject
    HttpServletRequest request;

    @Inject
    Models model;

    @QueryParam("icao")
    private String qpIcao;
    @QueryParam("aerodromi")
    private String qpAerodrom;
    @QueryParam("korisnik")
    private String qpKorisnik;
//    
//    @QueryParam("dozvola")
//    private String qpDozvola;

    @GET
    public String prikazAerodroma() {
        String odgovor = "";

        odgovor = autorizirajKorisnika();
        if (!odgovor.equals("OK")) {
            return odgovor;
        }

        odgovor = prikaziAerodrome();

        return odgovor;
    }

    @GET
    @Path("prikazPratiteljaAerodroma")
    public String prikazDozvolaKorisnika() {
        String odgovor = "";

        odgovor = autorizirajKorisnika();
        if (!odgovor.equals("OK")) {
            return odgovor;
        }

        odgovor = prikaziKorisnikePratitelje();

        return odgovor;
    }

    @GET
    @Path("zapratiAerodrom")
    public String zapratiAerodrom() {
        String odgovor = "";
        odgovor = autorizirajKorisnika();
        if (!odgovor.equals("OK")) {
            return odgovor;
        }
        
        zapratitiAerodom();
        
        odgovor = prikaziAerodrome();
        
        return odgovor;
    }
    
    private String zapratitiAerodom(){
        String odgovor = "pregledPracenjaAerodroma.jsp";
        
        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        AerodromiKlijent_2 ak2 = new AerodromiKlijent_2(qpAerodrom);
        Response r1 = ak2.dohvatiAerodrom(Response.class, korisnik, lozinka);
        if (r1.getStatusInfo().toString().equals("OK")) {
            Aerodrom a = new Gson().fromJson(r1.readEntity(String.class), Aerodrom.class);
            MojiAerodromiKlijent_3 mak3 = new MojiAerodromiKlijent_3(korisnik);
            Response r2 = mak3.dodajAerodromUListuPracenih(a, Response.class, korisnik, lozinka);
            if (r2.getStatusInfo().toString().equals("OK")) {
                model.put("porukaGreskeZapratiAerodrom", "Aerodrom uspjesno dodan !");
            } else {
                model.put("porukaGreskeZapratiAerodrom", r2.readEntity(String.class));
            }
        } else {
            model.put("porukaGreskeZapratiAerodrom", r1.readEntity(String.class));
        }
        
        //Poslati JMS poruku !!!!!!

        return odgovor;
    }

    @GET
    @Path("odpratiAerodrom")
    public String odpratiAerodrom() {
        String odgovor = "";
        odgovor = autorizirajKorisnika();
        if (!odgovor.equals("OK")) {
            return odgovor;
        }
        
        odpratitiAerodrom();
        
        odgovor = prikaziAerodrome();
        
        return odgovor;
    }
    
    private String odpratitiAerodrom(){
        String odgovor = "pregledPracenjaAerodroma.jsp";

        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");
        
        MojiAerodromiKlijent_4 ak4 = new MojiAerodromiKlijent_4(korisnik, qpIcao);
        Response r1 = ak4.obrisiAerodromIzListePracenih(Response.class, korisnik, lozinka);
        if (r1.getStatusInfo().toString().equals("OK")) {
            model.put("porukaGreskeZapratiAerodrom", "Aerodrom uspjesno obrisan !");
        } else {
            model.put("porukaGreskeZapratiAerodrom", r1.readEntity(String.class));
        }
        
        // Poslati JMS poruku !!!!!!

        return odgovor;
    }
    
    private String prikaziAerodrome() {
        String stranica = "";
        HttpSession sesija = request.getSession();

        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        MojiAerodromiKlijent_1 mak1 = new MojiAerodromiKlijent_1();
        Response r1 = mak1.dohvatiSvePraceneAerodrome(Response.class, korisnik, lozinka);
        if (r1.getStatusInfo().toString().equals("OK")) {
            Aerodrom[] a = new Gson().fromJson(r1.readEntity(String.class), Aerodrom[].class);
            List<Aerodrom> aerodromi = new ArrayList<>(Arrays.asList(a));
            model.put("praceniAerodromi", aerodromi);

            AerodromiKlijent_1 ak1 = new AerodromiKlijent_1();
            Response r2 = ak1.dajAerodrome(Response.class, "", "", korisnik, lozinka);
            Aerodrom[] a2 = new Gson().fromJson(r2.readEntity(String.class), Aerodrom[].class);
            List<Aerodrom> sviAerodromi = new ArrayList<>(Arrays.asList(a2));
            model.put("sviAerodromi", sviAerodromi);

            stranica = "pregledPracenjaAerodroma.jsp";

        } else {
            model.put("poruka", r1.readEntity(String.class));
            stranica = "pregledPracenjaAerodroma.jsp";
        }

        return stranica;
    }

    private String prikaziKorisnikePratitelje() {
        String stranica = "";
        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        MojiAerodromiKlijent_2 mak2 = new MojiAerodromiKlijent_2(qpIcao);
        Response r1 = mak2.dohvatiKorisnikeKojiPrateAerodrom(Response.class, korisnik, lozinka);
        if (r1.getStatusInfo().toString().equals("OK")) {
            Korisnik[] k = new Gson().fromJson(r1.readEntity(String.class), Korisnik[].class);
            List<Korisnik> korisnici = new ArrayList<>(Arrays.asList(k));
            model.put("listaPratitelja", korisnici);
            model.put("prikazKorisnika", true);
            model.put("nazivPracenogAerodroma", qpIcao);
            stranica = "pregledPracenjaAerodroma.jsp";
        } else {
            model.put("poruka", r1.readEntity(String.class));
            stranica = "pregledPracenjaAerodroma.jsp";
        }

        return stranica;
    }

    private String autorizirajKorisnika() {
        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        String komanda = "AUTHOR " + korisnik + " " + sesijaId + " administracijaAerodroma";
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            return "OK";
        } else if (dijeloviOdgovora[0].equals("ERROR")) {
            if (dijeloviOdgovora[1].equals("16")) {
                model.put("poruka", "Nema vise preostalih zahtjeva!");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("11")) {
                model.put("poruka", "Korisnik ne postoji !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("14")) {
                model.put("poruka", "Korisnik nema dozvolu za ovo podru�je !");
                return "izbornik.jsp";
            } else if (dijeloviOdgovora[1].equals("15")) {
                model.put("poruka", "Korisnik nema va�e�u sjednicu !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            }
        }
        return "";
    }

    private void obrisiSesiju(HttpSession sesija, int sesijaId, String korisnik) {
        String komanda = "LOGOUT " + korisnik + " " + sesijaId;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        // Salji poruku na '/login' krajnju to�ku s podacima o korisniku i aplikaciji te se veza zatvara
        sesija.removeAttribute("idSjednice");
        sesija.removeAttribute("korime");
        sesija.removeAttribute("lozinka");
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspje�no spajanje na serversku uti�nicu !";
        }
    }
}
