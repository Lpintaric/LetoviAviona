package org.foi.nwtis.lpintaric.projekt.controller;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Application;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.podaci.KorisniciKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.podaci.Aerodrom;

@Path("dozvole")
@Controller
public class KontrolerDozvole {

    @Inject
    ServletContext context;

    @Inject
    HttpServletRequest request;

    @Inject
    Models model;

    @QueryParam("korisnik")
    private String qpKorisnik;
    
    @QueryParam("dozvola")
    private String qpDozvola;

    @GET
    public String prikazKorisnika() {
        String stranica = "";

        stranica = prikaziKorisnike();

        return stranica;
    }

    @GET
    @Path("prikazDozvolaKorisnika")
    public String prikazDozvolaKorisnika() {
        String stranica = "";

        stranica = prikaziKorisnike();
        if (!stranica.equals("pregledDozvola.jsp")) {
            return stranica;
        }

        stranica = prikaziDozvole();

        return stranica;
    }

    @GET
    @Path("dodajDozvolu")
    public String dodajDozvolu() {
        String stranica = "";

        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        String komanda = "GRANT " + korisnik + " " + sesijaId + " " + request.getParameter("podrucja") + " " + qpKorisnik;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            model.put("porukaDozvola", "Uspjesno dodana dozvola !");
//            stranica = "pregledDozvola.jsp";
        } else if (dijeloviOdgovora[0].equals("ERROR")) {
            if (dijeloviOdgovora[1].equals("16")) {
                model.put("poruka", "Nema vise preostalih zahtjeva!");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("11")) {
                model.put("poruka", "Korisnik ne postoji !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("13")) {
                model.put("porukaDozvola", "Podrucje vec dodano !");
//                stranica = "pregledDozvola.jsp";
            } else if (dijeloviOdgovora[1].equals("15")) {
                model.put("porukaDozvola", "Ne postoji va�e�a sjednica !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            }
        }

        stranica = prikaziKorisnike();
        if (!stranica.equals("pregledDozvola.jsp")) {
            return stranica;
        }

        stranica = prikaziDozvole();

        return stranica;
    }
    
    @GET
    @Path("obrisiDozvolu")
    public String obrisiDozvolu() {
        String stranica = "";

        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        String komanda = "REVOKE " + korisnik + " " + sesijaId + " " + qpDozvola + " " + qpKorisnik;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            model.put("porukaDozvola", "Uspjesno obrisana dozvola !");
//            stranica = "pregledDozvola.jsp";
        } else if (dijeloviOdgovora[0].equals("ERROR")) {
            if (dijeloviOdgovora[1].equals("11")) {
                model.put("poruka", "Korisnik ne postoji !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("16")) {
                model.put("poruka", "Nema vise preostalih zahtjeva!");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("18")) {
                model.put("porukaDozvola", "Nema pridruzenog podrucja !");
//                stranica = "pregledDozvola.jsp";
            } else if (dijeloviOdgovora[1].equals("14")) {
                model.put("porukaDozvola", "Podrucje vec neaktivno !");
//                stranica = "pregledDozvola.jsp";
            } else if (dijeloviOdgovora[1].equals("15")) {
                model.put("porukaDozvola", "Ne postoji va�e�a sjednica !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                return "pocetna.jsp";
            }
        }

        stranica = prikaziKorisnike();
        if (!stranica.equals("pregledDozvola.jsp")) {
            return stranica;
        }

        stranica = prikaziDozvole();

        return stranica;
    }

    private String prikaziKorisnike() {
        String stranica = "";
        HttpSession sesija = request.getSession();

        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        String komanda = "AUTHOR " + korisnik + " " + sesijaId + " administracija";
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            KorisniciKlijent_1 kk1 = new KorisniciKlijent_1();
            Response r1 = kk1.dajKorisnike(Response.class, korisnik, lozinka);
            if (r1.getStatusInfo().toString().equals("OK")) {
                Korisnik[] k = new Gson().fromJson(r1.readEntity(String.class), Korisnik[].class);
                List<Korisnik> korisnici = new ArrayList<>(Arrays.asList(k));
                model.put("listaKorsnika", korisnici);
                stranica = "pregledDozvola.jsp";
            } else {
                model.put("poruka", r1.readEntity(String.class));
                stranica = "pregledDozvola.jsp";
            }

        } else if (dijeloviOdgovora[0].equals("ERROR")) {
            if (dijeloviOdgovora[1].equals("16")) {
                model.put("poruka", "Nema vise preostalih zahtjeva!");
                obrisiSesiju(sesija, sesijaId, korisnik);
                stranica = "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("11")) {
                model.put("poruka", "Korisnik ne postoji !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                stranica = "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("14")) {
                model.put("poruka", "Korisnik nema dozvolu za ovo podru�je !");
                stranica = "izbornik.jsp";
            } else if (dijeloviOdgovora[1].equals("15")) {
                model.put("poruka", "Korisnik nema va�e�u sjednicu !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                stranica = "pocetna.jsp";
            }
        }
        return stranica;
    }

    private String prikaziDozvole() {
        String stranica = "";
        HttpSession sesija = request.getSession();
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");
        String lozinka = (String) sesija.getAttribute("lozinka");

        String komanda = "RIGHTS " + korisnik + " " + sesijaId + " " + qpKorisnik;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        System.out.println(odgovor);

        if (dijeloviOdgovora[0].equals("OK")) {
            List<String> dozvole = new ArrayList<>();
            for (int i = 1; i < dijeloviOdgovora.length; i++) {
                dozvole.add(dijeloviOdgovora[i]);
            }
            model.put("listaDozvolaKorisnika", dozvole);
            model.put("ispisDozvolaKorisnika", true);
            model.put("korisnik", qpKorisnik);
            stranica = "pregledDozvola.jsp";

        } else if (dijeloviOdgovora[0].equals("ERROR")) {
            if (dijeloviOdgovora[1].equals("16")) {
                model.put("poruka", "Nema vise preostalih zahtjeva!");
                obrisiSesiju(sesija, sesijaId, korisnik);
                stranica = "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("11")) {
                model.put("poruka", "Korisnik ne postoji !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                stranica = "pocetna.jsp";
            } else if (dijeloviOdgovora[1].equals("14")) {
                model.put("poruka", "Nema aktivnih podrucja !");
                List<String> dozvole = null;
                model.put("listaDozvolaKorisnika", dozvole);
                model.put("ispisDozvolaKorisnika", true);
                model.put("korisnik", qpKorisnik);
                stranica = "pregledDozvola.jsp";
            } else if (dijeloviOdgovora[1].equals("15")) {
                model.put("poruka", "Korisnik nema va�e�u sjednicu !");
                obrisiSesiju(sesija, sesijaId, korisnik);
                stranica = "pocetna.jsp";
            }
        }
        return stranica;
    }

    private void obrisiSesiju(HttpSession sesija, int sesijaId, String korisnik) {
        String komanda = "LOGOUT " + korisnik + " " + sesijaId;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");
        
        // Salji poruku na '/login' krajnju to�ku s podacima o korisniku i aplikaciji te se veza zatvara
        
        sesija.removeAttribute("idSjednice");
        sesija.removeAttribute("korime");
        sesija.removeAttribute("lozinka");
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspje�no spajanje na serversku uti�nicu !";
        }
    }
}
