package org.foi.nwtis.lpintaric.projekt.controller;

import jakarta.enterprise.context.RequestScoped;
import jakarta.mvc.Controller;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

@Path("izbornik")
@Controller
public class KontrolerIzbornik {
    @GET
    @View("izbornik.jsp")
    public void izbornik() {
    }
}
