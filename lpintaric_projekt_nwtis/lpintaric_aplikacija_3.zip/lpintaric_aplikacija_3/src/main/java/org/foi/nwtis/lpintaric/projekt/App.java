package org.foi.nwtis.lpintaric.projekt;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/mvc")
public class App extends Application {
}
