package org.foi.nwtis.lpintaric.projekt.controller;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Application;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.AerodromiKlijent_2;
import org.foi.nwtis.lpintaric.projekt.podaci.KorisniciKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_2;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_3;
import org.foi.nwtis.lpintaric.projekt.podaci.MojiAerodromiKlijent_4;
import org.foi.nwtis.podaci.Aerodrom;

@Path("slanjeKomandi")
@Controller
public class KontrolerSlanjeKomandi {

    @Inject
    ServletContext context;

    @Inject
    HttpServletRequest request;

    @Inject
    Models model;

    @QueryParam("komanda")
    private String qpKomanda;
    
    @GET
    @View("slanjeKomandi.jsp")
    public void prikazPogleda() {

    }

    @GET
    @Path("posaljiKomandu")
    public String posaljiKomandu() {
        String odgovor = "";

        odgovor = posaljiKomanduNaPosluziteljKorisnika(qpKomanda);
        model.put("odgovor", odgovor);

        return "slanjeKomandi.jsp";
    }

   

    private void obrisiSesiju(HttpSession sesija, int sesijaId, String korisnik) {
        String komanda = "LOGOUT " + korisnik + " " + sesijaId;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        // Salji poruku na '/login' krajnju to�ku s podacima o korisniku i aplikaciji te se veza zatvara
        sesija.removeAttribute("idSjednice");
        sesija.removeAttribute("korime");
        sesija.removeAttribute("lozinka");
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspje�no spajanje na serversku uti�nicu !";
        }
    }
}
