package org.foi.nwtis.lpintaric.projekt.controller;

import com.sun.net.httpserver.HttpContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Application;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.wsep.OglasnikPrijava;
import org.foi.nwtis.podaci.Korisnik;

@Path("korisnikOdjava")
@Controller
public class KontrolerOdjava {

    @Inject
    ServletContext context;

    @Inject
    HttpServletRequest request;

    @Inject
    Models model;

    @Inject
    OglasnikPrijava oglasnikPrijava;

    @GET
    public String odjavaKorisnika() {
        String stranica = "";
        HttpSession sesija = request.getSession(false);
        int sesijaId = (int) sesija.getAttribute("idSjednice");
        String korisnik = (String) sesija.getAttribute("korime");

        String komanda = "LOGOUT " + korisnik + " " + sesijaId;
        String odgovor = posaljiKomanduNaPosluziteljKorisnika(komanda);
        String[] dijeloviOdgovora = odgovor.split(" ");

        if (dijeloviOdgovora[0].equals("OK")) {
            model.put("poruka", "Uspje�na odjava !");
            stranica = "pocetna.jsp";
        } else if (dijeloviOdgovora[0].equals("ERROR")) {
            if (dijeloviOdgovora[1].equals("15")) {
                model.put("poruka", "Sesija je ve� istekla !");
            } else if (dijeloviOdgovora[1].equals("11")) {
                model.put("poruka", "Korisnik ne postoji !");
            }
            stranica = "pocetna.jsp";
        }
        // Salji poruku na '/login' krajnju to�ku s podacima o korisniku i aplikaciji te se veza zatvara
        sesija.removeAttribute("idSjednice");
        sesija.removeAttribute("korime");
        sesija.removeAttribute("lozinka");

        String poruka = "ODJAVA;" + korisnik + ";lpintaric_aplikacija_3";
        oglasnikPrijava.posaljiPoruku(poruka);

        return stranica;
    }

    private String posaljiKomanduNaPosluziteljKorisnika(String komanda) {
        int port = (int) context.getAttribute("posluziteljKorisniciPort");
        String adresa = (String) context.getAttribute("posluziteljKorisniciAdresa");
        try (Socket uticnica = new Socket(adresa, port);
                InputStream is = uticnica.getInputStream();
                OutputStream os = uticnica.getOutputStream();) {

            os.write(komanda.getBytes());
            os.flush();
            uticnica.shutdownOutput();

            StringBuilder tekst = new StringBuilder();

            while (true) {
                int i = is.read();
                if (i == -1) {
                    break;
                }
                tekst.append((char) i);
            }

            uticnica.shutdownInput();

            uticnica.close();
            return tekst.toString();
        } catch (IOException ex) {
            return "ERROR Neuspje�no spajanje na serversku uti�nicu !";
        }
    }
}
