package org.foi.nwtis.lpintaric.projekt.controller;

import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import java.util.List;
import org.foi.nwtis.lpintaric.projekt.podaci.KorisniciKlijent_1;
import org.foi.nwtis.lpintaric.projekt.podaci.Korisnik;

@Path("korisnikRegistracija")
@Controller
public class KontrolerRegistracija {
    @Inject
    private Models model;

    @FormParam("korime")
    String korime;
    
    @FormParam("lozinka")
    String lozinka;
    
    @FormParam("prezime")
    String prezime;
        
    @FormParam("ime")
    String ime;
    
    @POST
    public String registracijaKorisnika() {
        String pogled = "";
        KorisniciKlijent_1 kk = new KorisniciKlijent_1();
        Korisnik k = new Korisnik(korime, lozinka, prezime, ime);
        Response odgovor = kk.dodajKorisnika(k, Response.class);
        
        System.out.println(odgovor.getStatusInfo().toString());
            
        if(odgovor.getStatusInfo().toString().equals("OK")){
            pogled = "korisnikPrijava.jsp";
        }else{
            model.put("greska", "Uneseni su neispravni podaci ili korisni�ko ime ve� postoji !");
            pogled = "greska.jsp";
        }

        return pogled;
    }
}
