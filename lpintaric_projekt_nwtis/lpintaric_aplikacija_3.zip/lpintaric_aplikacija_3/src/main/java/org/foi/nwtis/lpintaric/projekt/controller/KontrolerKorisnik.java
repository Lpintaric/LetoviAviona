package org.foi.nwtis.lpintaric.projekt.controller;

import jakarta.enterprise.context.RequestScoped;
import jakarta.mvc.Controller;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

@Path("korisnik")
@Controller
public class KontrolerKorisnik {
    @GET
    @Path("pocetna")
    @View("pocetna.jsp")
    public void pocetak() {
    }
    
    @Path("korisnikPrijava")
    @GET
    @View("korisnikPrijava.jsp")
    public void prijavaKorisnika() {
        return;
    }
    
    @Path("korisnikRegistracija")
    @GET
    @View("korisnikRegistracija.jsp")
    public void regitracijaKorisnika() {
        return;
    }
}
